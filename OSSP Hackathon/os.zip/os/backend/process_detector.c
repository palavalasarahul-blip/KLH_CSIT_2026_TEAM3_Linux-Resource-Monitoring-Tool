/**
 * ============================================================================
 * Project: Zombie and Orphan Process Detection System
 * File: backend/process_detector.c
 * 
 * Description:
 *   High-performance, robust Linux process scanner and classifier written in C.
 *   Directly interfaces with the Linux /proc filesystem to inspect process states,
 *   extract process metadata, identify parent-child relationships, and output
 *   structured JSON data for the Python GTK dashboard.
 * 
 * Operating Systems Concepts Demonstrated:
 *   - /proc virtual filesystem traversal
 *   - Robust parsing of /proc/[pid]/stat (handling spaces and parentheses in comm)
 *   - Process state enumeration (R: Running, S: Sleeping, D: Disk Sleep,
 *     Z: Zombie, T: Stopped, t: Tracing stop, X: Dead, I: Idle)
 *   - Parent-child hierarchy via PID and PPID mapping
 *   - Extraction of memory metrics (VmRSS, VmSize) and execution command lines
 * 
 * Compilation:
 *   gcc -O2 -Wall -Wextra -std=c11 backend/process_detector.c -o backend/process_detector
 * ============================================================================
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pwd.h>

#define MAX_PROCESSES 16384
#define MAX_NAME_LEN 256
#define MAX_CMD_LEN 1024
#define BUFFER_SIZE 4096

typedef struct {
    int pid;
    int ppid;
    char name[MAX_NAME_LEN];
    char parent_name[MAX_NAME_LEN];
    char state;
    char state_desc[32];
    long num_threads;
    long vmsize_kb;
    long vmrss_kb;
    uid_t uid;
    char username[64];
    char cmdline[MAX_CMD_LEN];
    int is_zombie;
    int is_orphan_candidate;
} ProcessInfo;

static ProcessInfo proc_list[MAX_PROCESSES];
static int proc_count = 0;

/**
 * Returns a human-readable description for a given Linux process state character.
 */
static const char *get_state_description(char state) {
    switch (state) {
        case 'R': return "Running";
        case 'S': return "Sleeping (Interruptible)";
        case 'D': return "Disk Sleep (Uninterruptible)";
        case 'Z': return "Zombie (Defunct)";
        case 'T': return "Stopped";
        case 't': return "Tracing Stop";
        case 'X': return "Dead";
        case 'x': return "Dead";
        case 'K': return "Wakekill";
        case 'W': return "Waking / Paging";
        case 'P': return "Parked";
        case 'I': return "Idle (Kernel Thread)";
        default:  return "Unknown";
    }
}

/**
 * Escapes a string to be safely embedded into a JSON string.
 */
static void json_escape(const char *src, char *dest, size_t max_dest) {
    size_t d_idx = 0;
    for (size_t s_idx = 0; src[s_idx] != '\0' && d_idx + 2 < max_dest; s_idx++) {
        unsigned char c = (unsigned char)src[s_idx];
        if (c == '"') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = '"';
        } else if (c == '\\') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = '\\';
        } else if (c == '\b') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = 'b';
        } else if (c == '\f') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = 'f';
        } else if (c == '\n') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = 'n';
        } else if (c == '\r') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = 'r';
        } else if (c == '\t') {
            dest[d_idx++] = '\\';
            dest[d_idx++] = 't';
        } else if (c < 32 || c >= 127) {
            // Replace non-printable ASCII or control characters with space or hex
            dest[d_idx++] = ' ';
        } else {
            dest[d_idx++] = c;
        }
    }
    dest[d_idx] = '\0';
}

/**
 * Parses /proc/[pid]/status to extract Uid, VmSize, and VmRSS.
 */
static void parse_proc_status(int pid, uid_t *uid, long *vmsize, long *vmrss) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);

    *uid = 0;
    *vmsize = 0;
    *vmrss = 0;

    FILE *fp = fopen(path, "r");
    if (!fp) return;

    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "Uid:", 4) == 0) {
            // Uid: real effective saved fs
            sscanf(line + 4, "%u", uid);
        } else if (strncmp(line, "VmSize:", 7) == 0) {
            sscanf(line + 7, "%ld", vmsize);
        } else if (strncmp(line, "VmRSS:", 6) == 0) {
            sscanf(line + 6, "%ld", vmrss);
        }
    }
    fclose(fp);
}

/**
 * Parses /proc/[pid]/cmdline to extract full command line arguments.
 */
static void parse_proc_cmdline(int pid, char *cmdline, size_t max_len, const char *fallback_name) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        snprintf(cmdline, max_len, "[%s]", fallback_name);
        return;
    }

    ssize_t bytes_read = read(fd, cmdline, max_len - 1);
    close(fd);

    if (bytes_read <= 0) {
        snprintf(cmdline, max_len, "[%s]", fallback_name);
        return;
    }

    cmdline[bytes_read] = '\0';

    // In /proc/[pid]/cmdline, arguments are separated by null bytes '\0'
    for (ssize_t i = 0; i < bytes_read - 1; i++) {
        if (cmdline[i] == '\0') {
            cmdline[i] = ' ';
        }
    }
}

/**
 * Safely parses /proc/[pid]/stat.
 * 
 * Standard format in Linux:
 *   pid (comm) state ppid pgrp session tty_nr tpgid flags minflt ...
 * 
 * Important Edge Case:
 *   The process name (comm) may contain spaces and parentheses, e.g. "(Web Content)".
 *   Therefore, standard sscanf with %s or %d (%s) fails!
 *   The robust, standard POSIX method is to:
 *   1. Find the first occurrence of '('
 *   2. Find the LAST occurrence of ')'
 *   3. Extract everything between first '(' and last ')' as the command name.
 *   4. Parse remaining numeric fields immediately after the last ')'.
 */
static int parse_proc_stat(int pid, ProcessInfo *info) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);

    FILE *fp = fopen(path, "r");
    if (!fp) return -1;

    char buffer[BUFFER_SIZE];
    if (!fgets(buffer, sizeof(buffer), fp)) {
        fclose(fp);
        return -1;
    }
    fclose(fp);

    char *first_paren = strchr(buffer, '(');
    char *last_paren = strrchr(buffer, ')');

    if (!first_paren || !last_paren || last_paren < first_paren) {
        return -1;
    }

    info->pid = pid;

    // Extract process comm between '(' and ')'
    size_t comm_len = (size_t)(last_paren - (first_paren + 1));
    if (comm_len >= sizeof(info->name)) {
        comm_len = sizeof(info->name) - 1;
    }
    strncpy(info->name, first_paren + 1, comm_len);
    info->name[comm_len] = '\0';

    // The fields after the last ')' start with a space followed by the single-letter state
    char *after = last_paren + 1;
    int ppid = 0;
    char state = '?';
    long num_threads = 1;

    // Read state and ppid
    // Format: " %c %d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %*lu %*lu %*ld %*ld %*ld %*ld %ld"
    // Field 3: state, Field 4: ppid, ..., Field 20: num_threads
    int fields_parsed = sscanf(after, " %c %d", &state, &ppid);
    if (fields_parsed < 2) {
        return -1;
    }

    info->state = state;
    info->ppid = ppid;
    info->is_zombie = (state == 'Z');
    strncpy(info->state_desc, get_state_description(state), sizeof(info->state_desc) - 1);

    // Scan for num_threads (field 20 of stat, which is 17th item after ')')
    // If scanning fails, default to 1
    int dummy_int;
    unsigned int dummy_uint;
    unsigned long dummy_ulong;
    long dummy_long;
    int full_scan = sscanf(after, " %c %d %d %d %d %d %u %lu %lu %lu %lu %lu %lu %ld %ld %ld %ld %ld",
                           &state, &ppid,
                           &dummy_int, &dummy_int, &dummy_int, &dummy_int,
                           &dummy_uint,
                           &dummy_ulong, &dummy_ulong, &dummy_ulong, &dummy_ulong,
                           &dummy_ulong, &dummy_ulong,
                           &dummy_long, &dummy_long, &dummy_long, &dummy_long,
                           &num_threads);
    if (full_scan >= 18) {
        info->num_threads = num_threads;
    } else {
        info->num_threads = 1;
    }

    // Default parent name
    strcpy(info->parent_name, "unknown");

    // Extract Uid, VmSize, VmRSS from /proc/[pid]/status
    parse_proc_status(pid, &info->uid, &info->vmsize_kb, &info->vmrss_kb);

    // Resolve username from uid
    struct passwd *pw = getpwuid(info->uid);
    if (pw) {
        strncpy(info->username, pw->pw_name, sizeof(info->username) - 1);
        info->username[sizeof(info->username) - 1] = '\0';
    } else {
        snprintf(info->username, sizeof(info->username), "%u", info->uid);
    }

    // Parse cmdline
    parse_proc_cmdline(pid, info->cmdline, sizeof(info->cmdline), info->name);

    return 0;
}

/**
 * Scans the entire /proc directory and loads all running processes into proc_list.
 */
static void scan_all_processes(void) {
    proc_count = 0;
    DIR *dir = opendir("/proc");
    if (!dir) {
        perror("opendir /proc");
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL && proc_count < MAX_PROCESSES) {
        // Process directories are strictly numeric
        if (isdigit(entry->d_name[0])) {
            int pid = atoi(entry->d_name);
            if (pid > 0) {
                if (parse_proc_stat(pid, &proc_list[proc_count]) == 0) {
                    proc_count++;
                }
            }
        }
    }
    closedir(dir);

    // Second pass: resolve parent names using our populated array
    for (int i = 0; i < proc_count; i++) {
        if (proc_list[i].ppid == 0) {
            strcpy(proc_list[i].parent_name, "[kernel]");
        } else {
            // Find parent in our array
            int found = 0;
            for (int j = 0; j < proc_count; j++) {
                if (proc_list[j].pid == proc_list[i].ppid) {
                    strncpy(proc_list[i].parent_name, proc_list[j].name, sizeof(proc_list[i].parent_name) - 1);
                    proc_list[i].parent_name[sizeof(proc_list[i].parent_name) - 1] = '\0';
                    found = 1;
                    break;
                }
            }
            if (!found) {
                // If parent not in list, try reading /proc/[ppid]/comm directly
                char comm_path[64];
                snprintf(comm_path, sizeof(comm_path), "/proc/%d/comm", proc_list[i].ppid);
                FILE *cfp = fopen(comm_path, "r");
                if (cfp) {
                    if (fgets(proc_list[i].parent_name, sizeof(proc_list[i].parent_name), cfp)) {
                        size_t l = strlen(proc_list[i].parent_name);
                        if (l > 0 && proc_list[i].parent_name[l - 1] == '\n') {
                            proc_list[i].parent_name[l - 1] = '\0';
                        }
                    }
                    fclose(cfp);
                } else {
                    strcpy(proc_list[i].parent_name, "[terminated/adopted]");
                }
            }
        }
    }
}

/**
 * Outputs the process list in JSON format.
 * filter_zombie_only: if 1, only prints processes with state == 'Z'
 */
static void output_json(int filter_zombie_only) {
    printf("[\n");
    int printed = 0;
    char escaped_name[MAX_NAME_LEN * 2];
    char escaped_parent[MAX_NAME_LEN * 2];
    char escaped_cmd[MAX_CMD_LEN * 2];
    char escaped_user[128];

    for (int i = 0; i < proc_count; i++) {
        ProcessInfo *p = &proc_list[i];
        if (filter_zombie_only && !p->is_zombie) {
            continue;
        }

        json_escape(p->name, escaped_name, sizeof(escaped_name));
        json_escape(p->parent_name, escaped_parent, sizeof(escaped_parent));
        json_escape(p->cmdline, escaped_cmd, sizeof(escaped_cmd));
        json_escape(p->username, escaped_user, sizeof(escaped_user));

        if (printed > 0) {
            printf(",\n");
        }

        printf("  {\n");
        printf("    \"pid\": %d,\n", p->pid);
        printf("    \"ppid\": %d,\n", p->ppid);
        printf("    \"name\": \"%s\",\n", escaped_name);
        printf("    \"parent_name\": \"%s\",\n", escaped_parent);
        printf("    \"state\": \"%c\",\n", p->state);
        printf("    \"state_desc\": \"%s\",\n", p->state_desc);
        printf("    \"threads\": %ld,\n", p->num_threads);
        printf("    \"vmsize_kb\": %ld,\n", p->vmsize_kb);
        printf("    \"vmrss_kb\": %ld,\n", p->vmrss_kb);
        printf("    \"uid\": %u,\n", p->uid);
        printf("    \"user\": \"%s\",\n", escaped_user);
        printf("    \"cmdline\": \"%s\",\n", escaped_cmd);
        printf("    \"is_zombie\": %s\n", p->is_zombie ? "true" : "false");
        printf("  }");

        printed++;
    }
    printf("\n]\n");
}

/**
 * Outputs a quick aggregate summary in JSON.
 */
static void output_summary(void) {
    int running = 0;
    int sleeping = 0;
    int disk_sleep = 0;
    int zombie = 0;
    int stopped = 0;
    int idle_kernel = 0;
    int other = 0;

    for (int i = 0; i < proc_count; i++) {
        switch (proc_list[i].state) {
            case 'R': running++; break;
            case 'S': sleeping++; break;
            case 'D': disk_sleep++; break;
            case 'Z': zombie++; break;
            case 'T':
            case 't': stopped++; break;
            case 'I': idle_kernel++; break;
            default:  other++; break;
        }
    }

    printf("{\n");
    printf("  \"total\": %d,\n", proc_count);
    printf("  \"running\": %d,\n", running);
    printf("  \"sleeping\": %d,\n", sleeping);
    printf("  \"disk_sleep\": %d,\n", disk_sleep);
    printf("  \"zombie\": %d,\n", zombie);
    printf("  \"stopped\": %d,\n", stopped);
    printf("  \"idle_kernel\": %d,\n", idle_kernel);
    printf("  \"other\": %d\n", other);
    printf("}\n");
}

/**
 * Outputs info for a single PID.
 */
static void output_single_pid(int target_pid) {
    ProcessInfo info;
    memset(&info, 0, sizeof(info));
    if (parse_proc_stat(target_pid, &info) != 0) {
        printf("{\"error\": \"Process %d not found or inaccessible\"}\n", target_pid);
        return;
    }

    // Try finding parent name
    char comm_path[64];
    snprintf(comm_path, sizeof(comm_path), "/proc/%d/comm", info.ppid);
    FILE *cfp = fopen(comm_path, "r");
    if (cfp) {
        if (fgets(info.parent_name, sizeof(info.parent_name), cfp)) {
            size_t l = strlen(info.parent_name);
            if (l > 0 && info.parent_name[l - 1] == '\n') {
                info.parent_name[l - 1] = '\0';
            }
        }
        fclose(cfp);
    } else {
        strcpy(info.parent_name, info.ppid == 0 ? "[kernel]" : "[terminated/adopted]");
    }

    char escaped_name[MAX_NAME_LEN * 2];
    char escaped_parent[MAX_NAME_LEN * 2];
    char escaped_cmd[MAX_CMD_LEN * 2];
    char escaped_user[128];

    json_escape(info.name, escaped_name, sizeof(escaped_name));
    json_escape(info.parent_name, escaped_parent, sizeof(escaped_parent));
    json_escape(info.cmdline, escaped_cmd, sizeof(escaped_cmd));
    json_escape(info.username, escaped_user, sizeof(escaped_user));

    printf("{\n");
    printf("  \"pid\": %d,\n", info.pid);
    printf("  \"ppid\": %d,\n", info.ppid);
    printf("  \"name\": \"%s\",\n", escaped_name);
    printf("  \"parent_name\": \"%s\",\n", escaped_parent);
    printf("  \"state\": \"%c\",\n", info.state);
    printf("  \"state_desc\": \"%s\",\n", info.state_desc);
    printf("  \"threads\": %ld,\n", info.num_threads);
    printf("  \"vmsize_kb\": %ld,\n", info.vmsize_kb);
    printf("  \"vmrss_kb\": %ld,\n", info.vmrss_kb);
    printf("  \"uid\": %u,\n", info.uid);
    printf("  \"user\": \"%s\",\n", escaped_user);
    printf("  \"cmdline\": \"%s\",\n", escaped_cmd);
    printf("  \"is_zombie\": %s\n", info.is_zombie ? "true" : "false");
    printf("}\n");
}

int main(int argc, char *argv[]) {
    int zombie_only = 0;
    int summary_only = 0;
    int single_pid = -1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--zombies") == 0 || strcmp(argv[i], "-z") == 0) {
            zombie_only = 1;
        } else if (strcmp(argv[i], "--summary") == 0 || strcmp(argv[i], "-s") == 0) {
            summary_only = 1;
        } else if ((strcmp(argv[i], "--pid") == 0 || strcmp(argv[i], "-p") == 0) && i + 1 < argc) {
            single_pid = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            fprintf(stderr, "Usage: %s [--json | --zombies | --summary | --pid <pid> | --help]\n", argv[0]);
            fprintf(stderr, "Options:\n");
            fprintf(stderr, "  --json       (default) Dump all active processes in JSON format\n");
            fprintf(stderr, "  --zombies    Dump only zombie (state Z) processes in JSON format\n");
            fprintf(stderr, "  --summary    Output aggregate counts (total, running, sleeping, zombies, etc.)\n");
            fprintf(stderr, "  --pid <pid>  Output information for a specific process ID\n");
            return 0;
        }
    }

    if (single_pid > 0) {
        output_single_pid(single_pid);
        return 0;
    }

    scan_all_processes();

    if (summary_only) {
        output_summary();
    } else {
        output_json(zombie_only);
    }

    return 0;
}
