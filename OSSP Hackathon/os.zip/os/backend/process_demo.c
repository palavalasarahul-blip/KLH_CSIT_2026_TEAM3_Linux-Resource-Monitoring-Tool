/**
 * ============================================================================
 * Project: Zombie and Orphan Process Detection System
 * File: backend/process_demo.c
 * 
 * Description:
 *   Controlled Process Demonstration Module written in C.
 *   Provides deterministic, safe, leak-free demonstrations of:
 *     1. Zombie Process Creation and Reaping
 *     2. Orphan Process Creation and OS Reparenting
 * 
 * Operating Systems Concepts:
 *   - fork(): duplicate the calling process into parent and child
 *   - exit(): terminate process, leaving exit status in task struct
 *   - wait() / waitpid(): parent collects child exit status, freeing PCB slot
 *   - Reparenting: kernel re-parents orphaned children to init (PID 1) or subreaper
 *   - Signal handling (SIGUSR1, SIGTERM, SIGALRM) for synchronization & safety
 * 
 * Safety Guarantee:
 *   All demo processes are equipped with automated timeout timers (SIGALRM)
 *   and signal traps to guarantee NO process leaks even if the GUI crashes.
 * ============================================================================
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

#define DEMO_ZOMBIE_COMM "demo_zombie"
#define DEMO_ORPHAN_COMM "demo_orphan"
#define DEMO_PARENT_COMM "demo_parent"

#define TIMEOUT_SECONDS 60
#define PID_FILE_ZOMBIE "/tmp/zombie_demo_parent.pid"
#define PID_FILE_ORPHAN "/tmp/orphan_demo_child.pid"

static volatile sig_atomic_t g_reap_requested = 0;
static volatile sig_atomic_t g_terminate_requested = 0;

static void handle_sigusr1(int sig) {
    (void)sig;
    g_reap_requested = 1;
}

static void handle_sigterm(int sig) {
    (void)sig;
    g_terminate_requested = 1;
}

static void handle_sigalrm(int sig) {
    (void)sig;
    // Timeout reached: force cleanup to prevent process leaks
    g_reap_requested = 1;
    g_terminate_requested = 1;
}

/**
 * Sets process name using prctl(PR_SET_NAME) for easy identification in /proc/[pid]/comm.
 */
static void set_process_comm(const char *name) {
#ifdef PR_SET_NAME
    prctl(PR_SET_NAME, name, 0, 0, 0);
#endif
}

/**
 * Spawns a Zombie Demonstration:
 * 1. Forks parent and child.
 * 2. Child exits immediately with code 42.
 * 3. Parent does NOT call waitpid() immediately.
 * 4. Child enters state 'Z' (Zombie / Defunct).
 * 5. Parent stays alive, listening for SIGUSR1 to reap, or SIGALRM timeout (60s).
 */
static int run_zombie_demo_parent(void) {
    // Configure signal handlers
    struct sigaction sa_usr1, sa_term, sa_alrm;
    memset(&sa_usr1, 0, sizeof(sa_usr1));
    sa_usr1.sa_handler = handle_sigusr1;
    sigaction(SIGUSR1, &sa_usr1, NULL);

    memset(&sa_term, 0, sizeof(sa_term));
    sa_term.sa_handler = handle_sigterm;
    sigaction(SIGTERM, &sa_term, NULL);

    memset(&sa_alrm, 0, sizeof(sa_alrm));
    sa_alrm.sa_handler = handle_sigalrm;
    sigaction(SIGALRM, &sa_alrm, NULL);

    set_process_comm(DEMO_PARENT_COMM);

    pid_t parent_pid = getpid();
    pid_t child_pid = fork();

    if (child_pid < 0) {
        printf("{\"status\": \"error\", \"message\": \"fork() failed: %s\"}\n", strerror(errno));
        fflush(stdout);
        return 1;
    }

    if (child_pid == 0) {
        // Child Process
        set_process_comm(DEMO_ZOMBIE_COMM);
        // Child exits immediately!
        // Because parent has not called wait(), child becomes a ZOMBIE.
        exit(42);
    }

    // Write parent and child PID info to stdout
    printf("{\"status\": \"zombie_created\", \"parent_pid\": %d, \"child_pid\": %d, \"timeout\": %d}\n",
           parent_pid, child_pid, TIMEOUT_SECONDS);
    fflush(stdout);

    // Save parent PID to temporary file for external reaper
    FILE *fp = fopen(PID_FILE_ZOMBIE, "w");
    if (fp) {
        fprintf(fp, "%d %d\n", parent_pid, child_pid);
        fclose(fp);
    }

    // Set safety alarm to prevent indefinite lingering
    alarm(TIMEOUT_SECONDS);

    // Parent waits for signal (SIGUSR1 to reap or SIGTERM to exit)
    while (!g_reap_requested && !g_terminate_requested) {
        pause();
    }

    // Parent reaps child using waitpid
    int status = 0;
    pid_t reaped_pid = waitpid(child_pid, &status, 0);

    unlink(PID_FILE_ZOMBIE);

    int exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
    printf("{\"status\": \"zombie_reaped\", \"parent_pid\": %d, \"child_pid\": %d, \"reaped_pid\": %d, \"exit_code\": %d}\n",
           parent_pid, child_pid, reaped_pid, exit_code);
    fflush(stdout);

    return 0;
}

/**
 * Commands an existing zombie demo parent to reap its child via SIGUSR1.
 */
static int reap_zombie_demo(int target_parent_pid) {
    if (target_parent_pid <= 0) {
        // Try reading from PID file
        FILE *fp = fopen(PID_FILE_ZOMBIE, "r");
        if (fp) {
            int ppid = 0, cpid = 0;
            if (fscanf(fp, "%d %d", &ppid, &cpid) == 2) {
                target_parent_pid = ppid;
            }
            fclose(fp);
        }
    }

    if (target_parent_pid <= 0) {
        printf("{\"status\": \"error\", \"message\": \"No active zombie demo parent found\"}\n");
        return 1;
    }

    if (kill(target_parent_pid, SIGUSR1) == 0) {
        printf("{\"status\": \"reap_signal_sent\", \"parent_pid\": %d}\n", target_parent_pid);
        return 0;
    } else {
        printf("{\"status\": \"error\", \"message\": \"Failed to signal parent %d: %s\"}\n",
               target_parent_pid, strerror(errno));
        return 1;
    }
}

/**
 * Spawns an Orphan Demonstration:
 * 1. Process forks an intermediate parent.
 * 2. Intermediate parent forks child.
 * 3. Child records original PPID and runs continuous sleep loop with timeout.
 * 4. Intermediate parent terminates immediately (exit 0).
 * 5. Linux kernel automatically re-parents the child process to init (PID 1) or user subreaper.
 */
static int run_orphan_demo(void) {
    int pipefd[2];
    if (pipe(pipefd) < 0) {
        printf("{\"status\": \"error\", \"message\": \"pipe() failed: %s\"}\n", strerror(errno));
        return 1;
    }

    pid_t intermediate_parent = fork();
    if (intermediate_parent < 0) {
        printf("{\"status\": \"error\", \"message\": \"fork() parent failed: %s\"}\n", strerror(errno));
        return 1;
    }

    if (intermediate_parent == 0) {
        // Intermediate Parent process
        close(pipefd[0]); // Close read end
        set_process_comm(DEMO_PARENT_COMM);

        pid_t child_pid = fork();
        if (child_pid < 0) {
            exit(1);
        }

        if (child_pid == 0) {
            // Child process (The destined Orphan)
            close(pipefd[1]);
            set_process_comm(DEMO_ORPHAN_COMM);

            // Redirect stdio to /dev/null so parent's subprocess pipe reaches EOF
            int devnull = open("/dev/null", O_RDWR);
            if (devnull >= 0) {
                dup2(devnull, STDIN_FILENO);
                dup2(devnull, STDOUT_FILENO);
                dup2(devnull, STDERR_FILENO);
                if (devnull > 2) close(devnull);
            }

            // Install safety alarm
            alarm(TIMEOUT_SECONDS);

            // Child keeps running until terminated or timeout
            while (1) {
                sleep(1);
            }
            exit(0);
        }

        // Intermediate Parent writes child info to main coordinator through pipe
        pid_t parent_pid = getpid();
        ssize_t w1 = write(pipefd[1], &parent_pid, sizeof(parent_pid));
        ssize_t w2 = write(pipefd[1], &child_pid, sizeof(child_pid));
        (void)w1;
        (void)w2;
        close(pipefd[1]);

        // Sleep briefly to ensure child is scheduled
        usleep(50000); // 50ms

        // Intermediate Parent TERMINATES intentionally!
        // This is what makes child_pid an ORPHAN!
        exit(0);
    }

    // Main coordinator process
    close(pipefd[1]); // Close write end

    pid_t original_parent = 0;
    pid_t orphan_child = 0;
    if (read(pipefd[0], &original_parent, sizeof(original_parent)) != sizeof(original_parent) ||
        read(pipefd[0], &orphan_child, sizeof(orphan_child)) != sizeof(orphan_child)) {
        printf("{\"status\": \"error\", \"message\": \"Failed to read orphan metadata from pipe\"}\n");
        close(pipefd[0]);
        return 1;
    }
    close(pipefd[0]);

    // Reap the intermediate parent so it doesn't linger as zombie
    int status;
    waitpid(intermediate_parent, &status, 0);

    // Save orphan child PID to temp file
    FILE *fp = fopen(PID_FILE_ORPHAN, "w");
    if (fp) {
        fprintf(fp, "%d %d\n", orphan_child, original_parent);
        fclose(fp);
    }

    // Give kernel a moment to complete reparenting
    usleep(100000); // 100ms

    // Check child's current PPID directly from /proc/[pid]/stat or via kill(0)
    int new_ppid = 1;
    char stat_path[64];
    snprintf(stat_path, sizeof(stat_path), "/proc/%d/stat", orphan_child);
    FILE *sfp = fopen(stat_path, "r");
    if (sfp) {
        char buf[512];
        if (fgets(buf, sizeof(buf), sfp)) {
            char *last_p = strrchr(buf, ')');
            if (last_p) {
                char dummy_state;
                sscanf(last_p + 1, " %c %d", &dummy_state, &new_ppid);
            }
        }
        fclose(sfp);
    }

    printf("{\"status\": \"orphan_created\", \"child_pid\": %d, \"original_ppid\": %d, \"new_ppid\": %d, \"timeout\": %d}\n",
           orphan_child, original_parent, new_ppid, TIMEOUT_SECONDS);
    fflush(stdout);

    return 0;
}

/**
 * Stops an active orphan demo process safely using SIGTERM (or SIGKILL if needed).
 */
static int stop_orphan_demo(int target_child_pid) {
    if (target_child_pid <= 0) {
        FILE *fp = fopen(PID_FILE_ORPHAN, "r");
        if (fp) {
            int cpid = 0, orig_ppid = 0;
            if (fscanf(fp, "%d %d", &cpid, &orig_ppid) == 2) {
                target_child_pid = cpid;
            }
            fclose(fp);
        }
    }

    if (target_child_pid <= 0) {
        printf("{\"status\": \"error\", \"message\": \"No active orphan child PID found\"}\n");
        return 1;
    }

    unlink(PID_FILE_ORPHAN);

    // Check if process exists
    if (kill(target_child_pid, 0) == 0) {
        kill(target_child_pid, SIGTERM);
        usleep(50000);
        if (kill(target_child_pid, 0) == 0) {
            kill(target_child_pid, SIGKILL);
        }
        printf("{\"status\": \"orphan_stopped\", \"child_pid\": %d}\n", target_child_pid);
        return 0;
    } else {
        printf("{\"status\": \"orphan_already_terminated\", \"child_pid\": %d}\n", target_child_pid);
        return 0;
    }
}

/**
 * Comprehensive Cleanup:
 * Kills any active demo parent or orphan processes created by this application.
 */
static void cleanup_all_demos(void) {
    int cleaned = 0;

    // Check zombie PID file
    FILE *fp = fopen(PID_FILE_ZOMBIE, "r");
    if (fp) {
        int ppid = 0, cpid = 0;
        if (fscanf(fp, "%d %d", &ppid, &cpid) == 2 && ppid > 0) {
            kill(ppid, SIGUSR1);
            usleep(20000);
            kill(ppid, SIGTERM);
            cleaned++;
        }
        fclose(fp);
        unlink(PID_FILE_ZOMBIE);
    }

    // Check orphan PID file
    fp = fopen(PID_FILE_ORPHAN, "r");
    if (fp) {
        int cpid = 0, ppid = 0;
        if (fscanf(fp, "%d %d", &cpid, &ppid) == 2 && cpid > 0) {
            kill(cpid, SIGKILL);
            cleaned++;
        }
        fclose(fp);
        unlink(PID_FILE_ORPHAN);
    }

    printf("{\"status\": \"cleanup_complete\", \"cleaned_count\": %d}\n", cleaned);
    fflush(stdout);
}

/**
 * Interactive Mode:
 * Reads commands on standard input and executes them, allowing a continuous
 * control channel from Python.
 */
static void run_interactive_mode(void) {
    char line[256];
    printf("{\"status\": \"interactive_ready\"}\n");
    fflush(stdout);

    while (fgets(line, sizeof(line), stdin)) {
        // Strip trailing newline
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) {
            line[--len] = '\0';
        }

        if (strcmp(line, "PING") == 0) {
            printf("{\"status\": \"PONG\"}\n");
        } else if (strcmp(line, "CLEANUP") == 0) {
            cleanup_all_demos();
        } else if (strcmp(line, "QUIT") == 0 || strcmp(line, "EXIT") == 0) {
            cleanup_all_demos();
            break;
        } else if (strncmp(line, "REAP_ZOMBIE", 11) == 0) {
            int ppid = 0;
            sscanf(line + 11, "%d", &ppid);
            reap_zombie_demo(ppid);
        } else if (strncmp(line, "STOP_ORPHAN", 11) == 0) {
            int cpid = 0;
            sscanf(line + 11, "%d", &cpid);
            stop_orphan_demo(cpid);
        } else {
            printf("{\"status\": \"unknown_command\", \"command\": \"%s\"}\n", line);
        }
        fflush(stdout);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s [--zombie-spawn | --zombie-reap [pid] | --orphan-spawn | --orphan-stop [pid] | --cleanup | --interactive]\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "--zombie-spawn") == 0) {
        return run_zombie_demo_parent();
    } else if (strcmp(argv[1], "--zombie-reap") == 0) {
        int pid = (argc >= 3) ? atoi(argv[2]) : 0;
        return reap_zombie_demo(pid);
    } else if (strcmp(argv[1], "--orphan-spawn") == 0) {
        return run_orphan_demo();
    } else if (strcmp(argv[1], "--orphan-stop") == 0) {
        int pid = (argc >= 3) ? atoi(argv[2]) : 0;
        return stop_orphan_demo(pid);
    } else if (strcmp(argv[1], "--cleanup") == 0) {
        cleanup_all_demos();
        return 0;
    } else if (strcmp(argv[1], "--interactive") == 0) {
        run_interactive_mode();
        return 0;
    } else {
        fprintf(stderr, "Unknown option: %s\n", argv[1]);
        return 1;
    }
}
