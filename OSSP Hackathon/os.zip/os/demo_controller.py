"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: demo_controller.py

Description:
    Controller module for safe, deterministic process demonstrations.
    Executes and coordinates the C demonstration engine (backend/process_demo)
    to create, monitor, reap, and clean up:
      - Zombie processes (fork -> child exit -> parent delays waitpid)
      - Orphan processes (fork parent & child -> parent exits -> child adopted by init)

Operating Systems Concepts:
    - fork() child creation and execution lifecycle
    - Dead child remaining in process table (State 'Z') until waitpid()
    - Subreaper and init adoption of orphaned process
    - Process cleanup and leak prevention guarantees
===============================================================================
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime
from typing import Dict, Any, Optional, Callable


class DemoController:
    def __init__(self, monitor=None, event_logger: Optional[Callable[[str, str], None]] = None):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.demo_bin_path = os.path.join(current_dir, "backend", "process_demo")
        self.monitor = monitor
        self.event_logger = event_logger

        # State tracking for active demonstrations
        self.active_zombie: Optional[Dict[str, Any]] = None
        self.active_orphan: Optional[Dict[str, Any]] = None

    def log(self, level: str, message: str):
        """Dispatches an event log message to the UI or standard output."""
        if self.event_logger:
            self.event_logger(level, message)
        else:
            ts = datetime.now().strftime("%H:%M:%S")
            print(f"[{ts}] [{level.upper()}] {message}")

    def spawn_zombie_demo(self) -> Dict[str, Any]:
        """
        Starts a zombie demonstration:
          - Child process is forked and exits immediately.
          - Parent process stays alive without waitpid(), leaving child in state 'Z'.
        """
        if self.active_zombie:
            self.log("warning", f"Zombie demo already running (Parent PID: {self.active_zombie['parent_pid']}, Child PID: {self.active_zombie['child_pid']}).")
            return {"status": "already_running", "data": self.active_zombie}

        if not os.path.exists(self.demo_bin_path):
            self.log("error", f"Demonstration binary not found at {self.demo_bin_path}. Run 'make' first.")
            return {"status": "error", "message": "Binary not found"}

        try:
            # Launch demo parent in background
            proc = subprocess.Popen(
                [self.demo_bin_path, "--zombie-spawn"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )

            # Read initial creation JSON from stdout
            stdout_line = proc.stdout.readline()
            if not stdout_line:
                self.log("error", "Zombie demo process produced no output.")
                return {"status": "error", "message": "No output from demo"}

            data = json.loads(stdout_line.strip())
            if data.get("status") == "zombie_created":
                parent_pid = data["parent_pid"]
                child_pid = data["child_pid"]
                self.active_zombie = {
                    "parent_pid": parent_pid,
                    "child_pid": child_pid,
                    "process": proc,
                    "start_time": time.time(),
                    "state": "zombie_active"
                }
                self.log("alert", f"Zombie created! Child PID {child_pid} terminated; Parent PID {parent_pid} has not called waitpid(). Child is in state 'Z'.")
                return {"status": "success", "parent_pid": parent_pid, "child_pid": child_pid}
            else:
                self.log("error", f"Unexpected zombie response: {stdout_line}")
                return {"status": "error", "message": stdout_line}

        except Exception as e:
            self.log("error", f"Failed to spawn zombie demo: {e}")
            return {"status": "error", "message": str(e)}

    def reap_zombie_demo(self) -> Dict[str, Any]:
        """
        Instructs the zombie parent process to execute waitpid(), reaping the child.
        """
        if not self.active_zombie:
            # Check if PID file exists on disk
            try:
                res = subprocess.run([self.demo_bin_path, "--zombie-reap"], stdout=subprocess.PIPE, text=True, timeout=3)
                self.log("info", f"Cleanup command dispatched: {res.stdout.strip()}")
            except Exception:
                pass
            self.log("warning", "No active zombie demo tracked in controller.")
            return {"status": "not_running"}

        parent_pid = self.active_zombie["parent_pid"]
        child_pid = self.active_zombie["child_pid"]
        proc = self.active_zombie.get("process")

        try:
            # Signal parent to reap
            res = subprocess.run(
                [self.demo_bin_path, "--zombie-reap", str(parent_pid)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3
            )
            # Give parent a brief moment to reap and exit
            if proc:
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.terminate()

            self.active_zombie = None
            self.log("info", f"Zombie PID {child_pid} successfully reaped by Parent PID {parent_pid} via waitpid(). Child removed from process table.")
            return {"status": "reaped", "child_pid": child_pid, "parent_pid": parent_pid}

        except Exception as e:
            self.log("error", f"Error reaping zombie: {e}")
            self.active_zombie = None
            return {"status": "error", "message": str(e)}

    def spawn_orphan_demo(self) -> Dict[str, Any]:
        """
        Starts an orphan demonstration:
          - Process forks an intermediate parent and child.
          - Intermediate parent intentionally terminates immediately.
          - Child continues running and is reparented to init (PID 1) / subreaper.
        """
        if self.active_orphan:
            self.log("warning", f"Orphan demo already running (Child PID: {self.active_orphan['child_pid']}).")
            return {"status": "already_running", "data": self.active_orphan}

        if not os.path.exists(self.demo_bin_path):
            self.log("error", f"Demonstration binary not found at {self.demo_bin_path}. Run 'make' first.")
            return {"status": "error", "message": "Binary not found"}

        try:
            res = subprocess.run(
                [self.demo_bin_path, "--orphan-spawn"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )

            stdout_line = res.stdout.strip()
            if not stdout_line:
                self.log("error", "Orphan demo produced no output.")
                return {"status": "error", "message": "No output"}

            data = json.loads(stdout_line)
            if data.get("status") == "orphan_created":
                child_pid = data["child_pid"]
                orig_ppid = data["original_ppid"]
                new_ppid = data.get("new_ppid", 1)

                self.active_orphan = {
                    "child_pid": child_pid,
                    "original_ppid": orig_ppid,
                    "new_ppid": new_ppid,
                    "start_time": time.time(),
                    "state": "orphan_active"
                }

                if self.monitor:
                    self.monitor.register_demo_orphan(child_pid, orig_ppid)

                self.log("alert", f"Orphan created! Original Parent PID {orig_ppid} terminated. Child PID {child_pid} has been reparented by kernel to PID {new_ppid} (init/subreaper).")
                return {"status": "success", "child_pid": child_pid, "original_ppid": orig_ppid, "new_ppid": new_ppid}
            else:
                self.log("error", f"Unexpected orphan response: {stdout_line}")
                return {"status": "error", "message": stdout_line}

        except Exception as e:
            self.log("error", f"Failed to spawn orphan demo: {e}")
            return {"status": "error", "message": str(e)}

    def stop_orphan_demo(self) -> Dict[str, Any]:
        """
        Safely terminates the running orphan demonstration child process.
        """
        if not self.active_orphan:
            try:
                res = subprocess.run([self.demo_bin_path, "--orphan-stop"], stdout=subprocess.PIPE, text=True, timeout=3)
                self.log("info", f"Orphan cleanup dispatched: {res.stdout.strip()}")
            except Exception:
                pass
            self.log("warning", "No active orphan demo tracked.")
            return {"status": "not_running"}

        child_pid = self.active_orphan["child_pid"]
        try:
            subprocess.run(
                [self.demo_bin_path, "--orphan-stop", str(child_pid)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3
            )

            if self.monitor:
                self.monitor.unregister_demo_orphan(child_pid)

            self.active_orphan = None
            self.log("info", f"Orphan demo process PID {child_pid} terminated and cleaned up safely.")
            return {"status": "stopped", "child_pid": child_pid}

        except Exception as e:
            self.log("error", f"Error stopping orphan demo: {e}")
            self.active_orphan = None
            return {"status": "error", "message": str(e)}

    def stop_all_demos(self):
        """Guarantees complete cleanup of all active demonstrations."""
        if self.active_zombie:
            self.reap_zombie_demo()
        if self.active_orphan:
            self.stop_orphan_demo()

        try:
            subprocess.run([self.demo_bin_path, "--cleanup"], stdout=subprocess.PIPE, text=True, timeout=3)
        except Exception:
            pass
        self.log("info", "All demonstrations stopped and demonstration state cleaned up.")

    def get_zombie_status(self) -> Optional[Dict[str, Any]]:
        """Returns metadata about the active zombie demo, if any."""
        if not self.active_zombie:
            return None
        elapsed = int(time.time() - self.active_zombie["start_time"])
        return {
            "parent_pid": self.active_zombie["parent_pid"],
            "child_pid": self.active_zombie["child_pid"],
            "elapsed_seconds": elapsed,
            "state": self.active_zombie["state"]
        }

    def get_orphan_status(self) -> Optional[Dict[str, Any]]:
        """Returns metadata about the active orphan demo, if any."""
        if not self.active_orphan:
            return None
        elapsed = int(time.time() - self.active_orphan["start_time"])
        return {
            "child_pid": self.active_orphan["child_pid"],
            "original_ppid": self.active_orphan["original_ppid"],
            "new_ppid": self.active_orphan["new_ppid"],
            "elapsed_seconds": elapsed,
            "state": self.active_orphan["state"]
        }
