"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/dashboard_view.py

Description:
    Executive overview dashboard displaying aggregate system process metrics,
    health status banners, quick alert feeds, and diagnostic actions.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import Dict, Any, List, Callable, Optional


class DashboardView(Gtk.Box):
    def __init__(self, navigation_callback: Optional[Callable[[str], None]] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.set_border_width(20)
        self.navigation_callback = navigation_callback

        # 1. Header Title
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='18' weight='bold' color='#f8fafc'>System Process Dashboard</span>")
        subtitle_lbl = Gtk.Label(xalign=0)
        subtitle_lbl.set_markup("<span color='#94a3b8'>Real-time Linux process state analysis, zombie detection, and orphan tracking</span>")
        title_box.pack_start(title_lbl, False, False, 0)
        title_box.pack_start(subtitle_lbl, False, False, 0)
        self.pack_start(title_box, False, False, 0)

        # 2. Dynamic Status Banner
        self.status_banner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.status_banner.get_style_context().add_class("status-banner")
        self.status_banner.get_style_context().add_class("status-healthy")
        self.status_icon = Gtk.Label()
        self.status_icon.set_markup("<span font='16'>✓</span>")
        self.status_text = Gtk.Label(xalign=0)
        self.status_text.set_markup("<b>System Status: Healthy</b> — Zero zombie processes detected. All parent-child states normal.")
        self.status_banner.pack_start(self.status_icon, False, False, 0)
        self.status_banner.pack_start(self.status_text, True, True, 0)
        self.pack_start(self.status_banner, False, False, 0)

        # 3. Metric Cards Grid
        metrics_grid = Gtk.Grid()
        metrics_grid.set_column_spacing(12)
        metrics_grid.set_row_spacing(12)
        metrics_grid.set_column_homogeneous(True)

        self.card_total = self._create_card("Total Processes", "0", "All active tasks in /proc", "metric-card-total")
        self.card_running = self._create_card("Running Tasks", "0", "State R (Active CPU)", "metric-card-running")
        self.card_sleeping = self._create_card("Sleeping Tasks", "0", "State S/D (Waiting/IO)", "")
        self.card_zombies = self._create_card("Zombie Processes", "0", "State Z (Defunct/Exit)", "metric-card-zombie")
        self.card_orphans = self._create_card("Detected Orphans", "0", "Adopted by init (PID 1)", "metric-card-orphan")
        self.card_refresh = self._create_card("Last Refresh", "Never", "Auto-refresh: 2s interval", "")

        metrics_grid.attach(self.card_total["container"], 0, 0, 1, 1)
        metrics_grid.attach(self.card_running["container"], 1, 0, 1, 1)
        metrics_grid.attach(self.card_sleeping["container"], 2, 0, 1, 1)
        metrics_grid.attach(self.card_zombies["container"], 0, 1, 1, 1)
        metrics_grid.attach(self.card_orphans["container"], 1, 1, 1, 1)
        metrics_grid.attach(self.card_refresh["container"], 2, 1, 1, 1)

        self.pack_start(metrics_grid, False, False, 0)

        # 4. Lower Two-Column Section: Alert Feed & Quick Actions
        lower_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        lower_box.set_homogeneous(True)

        # Left Panel: Recent Events / Alerts
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        left_panel.get_style_context().add_class("panel-card")
        left_title = Gtk.Label(xalign=0)
        left_title.set_markup("<span font='13' weight='bold' color='#f1f5f9'>🔔 Process Anomaly Feeds</span>")
        left_panel.pack_start(left_title, False, False, 0)

        self.alerts_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        scrolled_alerts = Gtk.ScrolledWindow()
        scrolled_alerts.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled_alerts.set_min_content_height(160)
        scrolled_alerts.add(self.alerts_box)
        left_panel.pack_start(scrolled_alerts, True, True, 0)

        # Right Panel: Quick Actions & OS Kernel Info
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        right_panel.get_style_context().add_class("panel-card")
        right_title = Gtk.Label(xalign=0)
        right_title.set_markup("<span font='13' weight='bold' color='#f1f5f9'>⚡ Quick Demonstration Lab Actions</span>")
        right_panel.pack_start(right_title, False, False, 0)

        info_lbl = Gtk.Label(xalign=0)
        info_lbl.set_line_wrap(True)
        info_lbl.set_markup(
            "<span color='#cbd5e1'>Explore live OS process behavior using the controlled simulation environment. Test how Linux creates defunct entries in the process table and reparents orphaned tasks to the root reaper (PID 1).</span>"
        )
        right_panel.pack_start(info_lbl, False, False, 0)

        actions_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        btn_demo = Gtk.Button(label="🧪 Open Controlled Demonstrations Lab")
        btn_demo.get_style_context().add_class("btn-primary")
        btn_demo.connect("clicked", lambda b: self._navigate("demo"))

        btn_tree = Gtk.Button(label="🌲 Inspect Process Hierarchy Tree")
        btn_tree.connect("clicked", lambda b: self._navigate("tree"))

        btn_zombies = Gtk.Button(label="🧟 View Zombie Processes List")
        btn_zombies.connect("clicked", lambda b: self._navigate("zombies"))

        actions_box.pack_start(btn_demo, False, False, 0)
        actions_box.pack_start(btn_tree, False, False, 0)
        actions_box.pack_start(btn_zombies, False, False, 0)
        right_panel.pack_start(actions_box, True, True, 4)

        lower_box.pack_start(left_panel, True, True, 0)
        lower_box.pack_start(right_panel, True, True, 0)
        self.pack_start(lower_box, True, True, 0)

    def _create_card(self, title: str, default_val: str, subtitle: str, extra_class: str) -> Dict[str, Any]:
        container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        container.get_style_context().add_class("metric-card")
        if extra_class:
            container.get_style_context().add_class(extra_class)

        t_lbl = Gtk.Label(xalign=0)
        t_lbl.set_markup(f"<span font='10' weight='bold' color='#94a3b8'>{title.upper()}</span>")

        v_lbl = Gtk.Label(xalign=0)
        v_lbl.set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{default_val}</span>")

        s_lbl = Gtk.Label(xalign=0)
        s_lbl.set_markup(f"<span font='10' color='#64748b'>{subtitle}</span>")

        container.pack_start(t_lbl, False, False, 0)
        container.pack_start(v_lbl, False, False, 0)
        container.pack_start(s_lbl, False, False, 0)

        return {"container": container, "value_label": v_lbl}

    def _navigate(self, page_id: str):
        if self.navigation_callback:
            self.navigation_callback(page_id)

    def update_view(self, summary: Dict[str, Any], zombies: List[Dict[str, Any]], orphans: List[Dict[str, Any]]):
        """Updates all metric cards and the status banner."""
        self.card_total["value_label"].set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{summary.get('total', 0)}</span>")
        self.card_running["value_label"].set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{summary.get('running', 0)}</span>")
        self.card_sleeping["value_label"].set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{summary.get('sleeping', 0)}</span>")
        self.card_zombies["value_label"].set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{summary.get('zombie', 0)}</span>")
        self.card_orphans["value_label"].set_markup(f"<span font='24' weight='bold' color='#f8fafc'>{summary.get('orphan', 0)}</span>")
        self.card_refresh["value_label"].set_markup(f"<span font='16' weight='bold' color='#38bdf8'>{summary.get('last_refresh', 'Never')}</span>")

        # Update status banner style and text
        sc = self.status_banner.get_style_context()
        sc.remove_class("status-healthy")
        sc.remove_class("status-alert-zombie")
        sc.remove_class("status-alert-orphan")

        z_count = len(zombies)
        o_count = len(orphans)

        if z_count > 0:
            sc.add_class("status-alert-zombie")
            self.status_icon.set_markup("<span font='16'>⚠️</span>")
            self.status_text.set_markup(
                f"<b>WARNING: {z_count} Zombie Process(es) Detected!</b> Awaiting parent waitpid() call to free process table entry."
            )
        elif o_count > 0:
            sc.add_class("status-alert-orphan")
            self.status_icon.set_markup("<span font='16'>ℹ️</span>")
            self.status_text.set_markup(
                f"<b>NOTICE: {o_count} Orphan Process(es) Detected!</b> Original parent exited; adopted by init/subreaper."
            )
        else:
            sc.add_class("status-healthy")
            self.status_icon.set_markup("<span font='16'>✓</span>")
            self.status_text.set_markup(
                "<b>System Status: Healthy</b> — Zero zombie processes detected. All parent-child states normal."
            )

        # Update alerts box
        for child in self.alerts_box.get_children():
            self.alerts_box.remove(child)

        if z_count == 0 and o_count == 0:
            empty_lbl = Gtk.Label(xalign=0)
            empty_lbl.set_markup("<span color='#64748b'>No active warnings or process anomalies.</span>")
            self.alerts_box.pack_start(empty_lbl, False, False, 4)
        else:
            for z in zombies:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                lbl = Gtk.Label(xalign=0)
                lbl.set_markup(
                    f"<span color='#ef4444' weight='bold'>[ZOMBIE]</span> PID <span font_family='monospace'>{z['pid']}</span> "
                    f"({z['name']}) — Parent: {z.get('parent_name', 'unknown')} (PID {z['ppid']})"
                )
                row.pack_start(lbl, True, True, 0)
                self.alerts_box.pack_start(row, False, False, 2)

            for o in orphans:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                lbl = Gtk.Label(xalign=0)
                lbl.set_markup(
                    f"<span color='#f59e0b' weight='bold'>[ORPHAN]</span> PID <span font_family='monospace'>{o['pid']}</span> "
                    f"({o['name']}) — {o.get('orphan_reason', 'Adopted by init')}"
                )
                row.pack_start(lbl, True, True, 0)
                self.alerts_box.pack_start(row, False, False, 2)

        self.show_all()
