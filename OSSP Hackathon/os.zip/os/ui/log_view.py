"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/log_view.py

Description:
    Real-time timestamped event stream displaying monitoring state changes,
    anomaly discoveries, process lifecycles, and demonstration outcomes.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from datetime import datetime
from typing import List, Dict, Any, Optional


class EventLogView(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.set_border_width(20)

        # 1. Header & Controls
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='16' weight='bold' color='#f8fafc'>📜 System &amp; Diagnostic Event Log</span>")
        self.count_lbl = Gtk.Label(xalign=0)
        self.count_lbl.set_markup("<span color='#94a3b8'>0 events recorded</span>")
        title_box.pack_start(title_lbl, False, False, 0)
        title_box.pack_start(self.count_lbl, False, False, 0)
        header_box.pack_start(title_box, False, False, 0)

        spacer = Gtk.Box()
        header_box.pack_start(spacer, True, True, 0)

        btn_clear = Gtk.Button(label="🗑️ Clear Log")
        btn_clear.connect("clicked", self._on_clear_log)

        btn_export = Gtk.Button(label="💾 Export Log")
        btn_export.connect("clicked", self._on_export_log)

        header_box.pack_start(btn_clear, False, False, 0)
        header_box.pack_start(btn_export, False, False, 0)

        self.pack_start(header_box, False, False, 0)

        # 2. Log Table
        # Columns: 0: Timestamp, 1: Level Badge Markup, 2: Message, 3: Raw level (str)
        self.list_store = Gtk.ListStore(str, str, str, str)
        self.tree_view = Gtk.TreeView(model=self.list_store)
        self.tree_view.set_rules_hint(True)

        self._build_columns()

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(450)
        scrolled.add(self.tree_view)
        self.pack_start(scrolled, True, True, 0)

        self.status_bar = Gtk.Label(xalign=0)
        self.status_bar.set_markup("<span color='#64748b'>Ready. Logging all system state changes.</span>")
        self.pack_start(self.status_bar, False, False, 0)

    def _build_columns(self):
        # Timestamp
        r_time = Gtk.CellRendererText()
        col_time = Gtk.TreeViewColumn("Timestamp", r_time, text=0)
        col_time.set_min_width(100)
        self.tree_view.append_column(col_time)

        # Level Badge
        r_level = Gtk.CellRendererText()
        col_level = Gtk.TreeViewColumn("Severity", r_level, markup=1)
        col_level.set_min_width(100)
        self.tree_view.append_column(col_level)

        # Message
        r_msg = Gtk.CellRendererText()
        col_msg = Gtk.TreeViewColumn("Event Description", r_msg, text=2)
        col_msg.set_min_width(450)
        col_msg.set_resizable(True)
        self.tree_view.append_column(col_msg)

    def add_entry(self, level: str, message: str):
        """Adds a new timestamped event entry to the log view."""
        ts = datetime.now().strftime("%H:%M:%S")
        lvl = level.upper()

        if lvl == "ALERT":
            badge = "<span background='#ef4444' color='#ffffff' weight='bold'> ALERT </span>"
        elif lvl == "WARNING":
            badge = "<span background='#f59e0b' color='#000000' weight='bold'> WARN </span>"
        elif lvl == "ERROR":
            badge = "<span background='#dc2626' color='#ffffff' weight='bold'> ERROR </span>"
        else:
            badge = "<span background='#3b82f6' color='#ffffff'> INFO </span>"

        # Prepend to display newest first
        self.list_store.prepend([ts, badge, message, lvl])
        count = len(self.list_store)
        self.count_lbl.set_markup(f"<span color='#94a3b8'>{count} events recorded</span>")

    def _on_clear_log(self, button):
        self.list_store.clear()
        self.count_lbl.set_markup("<span color='#94a3b8'>0 events recorded</span>")
        self.status_bar.set_markup("<span color='#64748b'>Log buffer cleared.</span>")

    def _on_export_log(self, button):
        export_path = "/tmp/zombie_orphan_event_log.txt"
        try:
            with open(export_path, "w", encoding="utf-8") as f:
                f.write("Zombie & Orphan Detection System — Event Log Export\n")
                f.write("=" * 60 + "\n\n")
                iter = self.list_store.get_iter_first()
                while iter:
                    ts = self.list_store[iter][0]
                    lvl = self.list_store[iter][3]
                    msg = self.list_store[iter][2]
                    f.write(f"[{ts}] [{lvl:7s}] {msg}\n")
                    iter = self.list_store.iter_next(iter)
            self.status_bar.set_markup(f"<span color='#10b981'>Log successfully exported to <tt>{export_path}</tt></span>")
        except Exception as e:
            self.status_bar.set_markup(f"<span color='#ef4444'>Failed to export log: {e}</span>")
