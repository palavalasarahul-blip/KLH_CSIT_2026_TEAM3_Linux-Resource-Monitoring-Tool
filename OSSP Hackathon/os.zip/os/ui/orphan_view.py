"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/orphan_view.py

Description:
    Dedicated Orphan Process Detection and Reparenting View.
    Displays verified orphan processes that have been reparented to init (PID 1)
    or a configured subreaper, clearly differentiating them from standard system daemons.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import List, Dict, Any, Callable, Optional


class OrphanView(Gtk.Box):
    def __init__(self, navigation_callback: Optional[Callable[[str], None]] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.set_border_width(20)
        self.navigation_callback = navigation_callback
        self.current_orphans: List[Dict[str, Any]] = []

        # 1. Header Box
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='18' weight='bold' color='#f59e0b'>🐣 Orphan Process Detection</span>")
        subtitle_lbl = Gtk.Label(xalign=0)
        subtitle_lbl.set_markup("<span color='#94a3b8'>Analysis of processes adopted by init (PID 1) or system subreapers</span>")
        header_box.pack_start(title_lbl, False, False, 0)
        header_box.pack_start(subtitle_lbl, False, False, 0)
        self.pack_start(header_box, False, False, 0)

        # 2. Operating System Concept & Important Differentiation Card
        theory_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        theory_card.get_style_context().add_class("panel-card")
        theory_card.get_style_context().add_class("metric-card-orphan")

        theory_title = Gtk.Label(xalign=0)
        theory_title.set_markup("<span font='13' weight='bold' color='#fbbf24'>Operating Systems Theory: Process Reparenting &amp; Daemons</span>")

        theory_body = Gtk.Label(xalign=0)
        theory_body.set_line_wrap(True)
        theory_body.set_markup(
            "<span color='#cbd5e1'>An <b>orphan process</b> is a running process whose original parent has terminated prematurely. "
            "Because Unix processes must always have a valid parent to collect their exit status, the Linux kernel automatically <b>reparents</b> "
            "the orphan to <tt>PID 1</tt> (<tt>systemd</tt> / <tt>init</tt>) or the nearest configured subreaper (<tt>prctl(PR_SET_CHILD_SUBREAPER)</tt>).\n\n"
            "<b>Crucial Academic Distinction:</b> Not every process with <tt>PPID 1</tt> is an orphan! Standard background services (e.g., <tt>cron</tt>, <tt>dbus</tt>, <tt>sshd</tt>) "
            "are deliberately created under PID 1. This system uses dynamic lifecycle genealogy tracking and controlled demo registration to identify <i>true</i> reparented orphans.</span>"
        )
        theory_card.pack_start(theory_title, False, False, 0)
        theory_card.pack_start(theory_body, False, False, 0)
        self.pack_start(theory_card, False, False, 0)

        # 3. Action Bar
        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.count_badge = Gtk.Label(xalign=0)
        self.count_badge.set_markup("<span font='13' weight='bold' color='#f8fafc'>Detected Orphans: 0</span>")
        action_bar.pack_start(self.count_badge, False, False, 0)

        spacer = Gtk.Box()
        action_bar.pack_start(spacer, True, True, 0)

        btn_demo = Gtk.Button(label="🧪 Create Orphan in Demonstration Lab")
        btn_demo.get_style_context().add_class("btn-warning")
        btn_demo.connect("clicked", lambda b: self._navigate("demo"))
        action_bar.pack_start(btn_demo, False, False, 0)

        self.pack_start(action_bar, False, False, 0)

        # 4. Orphan Process Table
        # Columns: 0: Child PID, 1: Adopted PPID, 2: Original Parent, 3: Name, 4: State, 5: Type, 6: Evidence/Reason, 7: Raw dict
        self.list_store = Gtk.ListStore(int, int, str, str, str, str, str, object)
        self.tree_view = Gtk.TreeView(model=self.list_store)
        self.tree_view.set_rules_hint(True)

        self._build_columns()

        self.scrolled = Gtk.ScrolledWindow()
        self.scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.scrolled.set_min_content_height(250)
        self.scrolled.add(self.tree_view)
        self.pack_start(self.scrolled, True, True, 0)

        # 5. Empty State Container
        self.empty_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.empty_box.get_style_context().add_class("panel-card")
        empty_lbl = Gtk.Label()
        empty_lbl.set_markup(
            "<span font='14' weight='bold' color='#10b981'>✓ Zero Reparented Orphan Processes Detected</span>\n"
            "<span color='#94a3b8'>No processes have suffered parent termination during active monitoring. Launch an Orphan Demonstration to observe real-time kernel adoption.</span>"
        )
        empty_lbl.set_justify(Gtk.Justification.CENTER)
        self.empty_box.pack_start(empty_lbl, True, True, 16)
        self.pack_start(self.empty_box, False, False, 0)

    def _build_columns(self):
        # Child PID
        r_cpid = Gtk.CellRendererText()
        col_cpid = Gtk.TreeViewColumn("Orphan PID", r_cpid, text=0)
        col_cpid.set_min_width(90)
        self.tree_view.append_column(col_cpid)

        # Adopted PPID
        r_ppid = Gtk.CellRendererText()
        col_ppid = Gtk.TreeViewColumn("Adopted PPID", r_ppid, text=1)
        col_ppid.set_min_width(90)
        self.tree_view.append_column(col_ppid)

        # Process Name
        r_name = Gtk.CellRendererText()
        col_name = Gtk.TreeViewColumn("Process Name", r_name, text=3)
        col_name.set_min_width(160)
        self.tree_view.append_column(col_name)

        # Original Parent
        r_oparent = Gtk.CellRendererText()
        col_oparent = Gtk.TreeViewColumn("Original Parent", r_oparent, text=2)
        col_oparent.set_min_width(140)
        self.tree_view.append_column(col_oparent)

        # State
        r_state = Gtk.CellRendererText()
        col_state = Gtk.TreeViewColumn("State", r_state, text=4)
        col_state.set_min_width(60)
        self.tree_view.append_column(col_state)

        # Detection Type
        r_type = Gtk.CellRendererText()
        col_type = Gtk.TreeViewColumn("Detection Type", r_type, text=5)
        col_type.set_min_width(160)
        self.tree_view.append_column(col_type)

        # Evidence / Reason
        r_reason = Gtk.CellRendererText()
        col_reason = Gtk.TreeViewColumn("Reparenting Evidence", r_reason, markup=6)
        col_reason.set_min_width(260)
        self.tree_view.append_column(col_reason)

    def _navigate(self, page_id: str):
        if self.navigation_callback:
            self.navigation_callback(page_id)

    def update_orphans(self, orphans: List[Dict[str, Any]]):
        self.current_orphans = orphans
        self.list_store.clear()

        count = len(orphans)
        self.count_badge.set_markup(
            f"<span font='13' weight='bold' color='{'#f59e0b' if count > 0 else '#10b981'}'>Detected Orphans: {count}</span>"
        )

        if count == 0:
            self.scrolled.hide()
            self.empty_box.show_all()
        else:
            self.empty_box.hide()
            self.scrolled.show_all()

            for o in orphans:
                reason_markup = f"<span color='#fbbf24'>{o.get('orphan_reason', 'Adopted by PID 1')}</span>"
                self.list_store.append([
                    o["pid"], o["ppid"], o.get("original_parent", "terminated"),
                    o["name"], o["state"], o.get("orphan_type", "Orphan Process"),
                    reason_markup, o
                ])
