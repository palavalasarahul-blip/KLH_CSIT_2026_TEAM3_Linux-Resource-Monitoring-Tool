"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/demo_view.py

Description:
    Interactive Laboratory for Controlled Process Demonstrations.
    Allows students, evaluators, and engineers to trigger, observe, and reap:
      1. Zombie processes (demonstrating fork, child exit, and deferred waitpid)
      2. Orphan processes (demonstrating parent termination and kernel reparenting)
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import Dict, Any, Optional
import demo_controller


class DemonstrationView(Gtk.Box):
    def __init__(self, controller: demo_controller.DemoController):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.set_border_width(20)
        self.controller = controller

        # 1. Header Box
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='18' weight='bold' color='#38bdf8'>🧪 Controlled Demonstration Lab</span>")
        subtitle_lbl = Gtk.Label(xalign=0)
        subtitle_lbl.set_markup(
            "<span color='#94a3b8'>Execute safe, leak-free operating system experiments demonstrating process lifecycles</span>"
        )
        header_box.pack_start(title_lbl, False, False, 0)
        header_box.pack_start(subtitle_lbl, False, False, 0)
        self.pack_start(header_box, False, False, 0)

        # 2. Safety Notice Banner
        safety_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        safety_box.get_style_context().add_class("status-banner")
        safety_box.get_style_context().add_class("status-healthy")
        icon = Gtk.Label()
        icon.set_markup("<span font='16'>🛡️</span>")
        safety_lbl = Gtk.Label(xalign=0)
        safety_lbl.set_line_wrap(True)
        safety_lbl.set_markup(
            "<b>Safety Guarantee:</b> All demonstration processes are strictly scoped to this application. "
            "They utilize POSIX timers (<tt>SIGALRM</tt>) with automated 60-second timeouts to prevent process leaks."
        )
        safety_box.pack_start(icon, False, False, 0)
        safety_box.pack_start(safety_lbl, True, True, 0)
        self.pack_start(safety_box, False, False, 0)

        # 3. Two Main Experiment Columns
        experiments_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        experiments_box.set_homogeneous(True)

        # --- Experiment 1: Zombie Demo ---
        zombie_panel = self._build_zombie_panel()
        experiments_box.pack_start(zombie_panel, True, True, 0)

        # --- Experiment 2: Orphan Demo ---
        orphan_panel = self._build_orphan_panel()
        experiments_box.pack_start(orphan_panel, True, True, 0)

        self.pack_start(experiments_box, True, True, 0)

        # 4. Global Cleanup Bar
        cleanup_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        cleanup_box.get_style_context().add_class("panel-card")

        cleanup_lbl = Gtk.Label(xalign=0)
        cleanup_lbl.set_markup("<span color='#94a3b8'>End of evaluation or cleanup required? Terminate all spawned demo processes:</span>")
        cleanup_box.pack_start(cleanup_lbl, True, True, 0)

        btn_cleanup = Gtk.Button(label="🧹 Stop All Demos & Clean Up")
        btn_cleanup.get_style_context().add_class("btn-danger")
        btn_cleanup.connect("clicked", self._on_stop_all)
        cleanup_box.pack_start(btn_cleanup, False, False, 0)

        self.pack_start(cleanup_box, False, False, 0)

    def _build_zombie_panel(self) -> Gtk.Box:
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        panel.get_style_context().add_class("panel-card")
        panel.get_style_context().add_class("metric-card-zombie")

        title = Gtk.Label(xalign=0)
        title.set_markup("<span font='14' weight='bold' color='#ef4444'>Experiment 1: Zombie Process Creation</span>")
        panel.pack_start(title, False, False, 0)

        desc = Gtk.Label(xalign=0)
        desc.set_line_wrap(True)
        desc.set_markup(
            "<span color='#cbd5e1'>1. The C engine calls <tt>fork()</tt> to spawn a child process.\n"
            "2. The child exits immediately (<tt>exit(42)</tt>).\n"
            "3. The parent intentionally does NOT call <tt>waitpid()</tt>.\n"
            "4. The child enters state <b>'Z' (Zombie)</b> in the Linux process table.\n"
            "5. Clicking <i>Reap Zombie</i> sends <tt>SIGUSR1</tt> to invoke <tt>waitpid()</tt>.</span>"
        )
        panel.pack_start(desc, False, False, 0)

        # Status Display Box
        self.zombie_status_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.zombie_status_card.get_style_context().add_class("panel-card")

        self.zombie_status_lbl = Gtk.Label(xalign=0)
        self.zombie_status_lbl.set_markup("<b>Status:</b> Idle (No active zombie demo)")
        self.zombie_parent_lbl = Gtk.Label(xalign=0)
        self.zombie_parent_lbl.set_markup("<span color='#94a3b8'>Parent PID:</span> -")
        self.zombie_child_lbl = Gtk.Label(xalign=0)
        self.zombie_child_lbl.set_markup("<span color='#94a3b8'>Zombie Child PID:</span> -")
        self.zombie_time_lbl = Gtk.Label(xalign=0)
        self.zombie_time_lbl.set_markup("<span color='#94a3b8'>Elapsed / Timeout:</span> -")

        self.zombie_status_card.pack_start(self.zombie_status_lbl, False, False, 0)
        self.zombie_status_card.pack_start(self.zombie_parent_lbl, False, False, 0)
        self.zombie_status_card.pack_start(self.zombie_child_lbl, False, False, 0)
        self.zombie_status_card.pack_start(self.zombie_time_lbl, False, False, 0)
        panel.pack_start(self.zombie_status_card, False, False, 0)

        # Button Controls
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.btn_spawn_zombie = Gtk.Button(label="Create Zombie Demo")
        self.btn_spawn_zombie.get_style_context().add_class("btn-danger")
        self.btn_spawn_zombie.connect("clicked", self._on_spawn_zombie)

        self.btn_reap_zombie = Gtk.Button(label="Reap Zombie (waitpid)")
        self.btn_reap_zombie.get_style_context().add_class("btn-success")
        self.btn_reap_zombie.set_sensitive(False)
        self.btn_reap_zombie.connect("clicked", self._on_reap_zombie)

        btn_box.pack_start(self.btn_spawn_zombie, True, True, 0)
        btn_box.pack_start(self.btn_reap_zombie, True, True, 0)
        panel.pack_start(btn_box, False, False, 4)

        return panel

    def _build_orphan_panel(self) -> Gtk.Box:
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        panel.get_style_context().add_class("panel-card")
        panel.get_style_context().add_class("metric-card-orphan")

        title = Gtk.Label(xalign=0)
        title.set_markup("<span font='14' weight='bold' color='#f59e0b'>Experiment 2: Orphan Process Reparenting</span>")
        panel.pack_start(title, False, False, 0)

        desc = Gtk.Label(xalign=0)
        desc.set_line_wrap(True)
        desc.set_markup(
            "<span color='#cbd5e1'>1. The engine creates an intermediate parent and child process.\n"
            "2. The child process begins executing in a background sleep loop.\n"
            "3. The intermediate parent <b>terminates intentionally</b> (<tt>exit(0)</tt>).\n"
            "4. The Linux kernel observes an orphan and <b>reparents</b> it to PID 1.\n"
            "5. The child process continues execution safely under init adoption.</span>"
        )
        panel.pack_start(desc, False, False, 0)

        # Status Display Box
        self.orphan_status_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.orphan_status_card.get_style_context().add_class("panel-card")

        self.orphan_status_lbl = Gtk.Label(xalign=0)
        self.orphan_status_lbl.set_markup("<b>Status:</b> Idle (No active orphan demo)")
        self.orphan_old_parent_lbl = Gtk.Label(xalign=0)
        self.orphan_old_parent_lbl.set_markup("<span color='#94a3b8'>Original Parent PID:</span> -")
        self.orphan_child_lbl = Gtk.Label(xalign=0)
        self.orphan_child_lbl.set_markup("<span color='#94a3b8'>Orphan Child PID:</span> -")
        self.orphan_new_ppid_lbl = Gtk.Label(xalign=0)
        self.orphan_new_ppid_lbl.set_markup("<span color='#94a3b8'>Adopted By (PPID):</span> -")

        self.orphan_status_card.pack_start(self.orphan_status_lbl, False, False, 0)
        self.orphan_status_card.pack_start(self.orphan_old_parent_lbl, False, False, 0)
        self.orphan_status_card.pack_start(self.orphan_child_lbl, False, False, 0)
        self.orphan_status_card.pack_start(self.orphan_new_ppid_lbl, False, False, 0)
        panel.pack_start(self.orphan_status_card, False, False, 0)

        # Button Controls
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.btn_spawn_orphan = Gtk.Button(label="Create Orphan Demo")
        self.btn_spawn_orphan.get_style_context().add_class("btn-warning")
        self.btn_spawn_orphan.connect("clicked", self._on_spawn_orphan)

        self.btn_stop_orphan = Gtk.Button(label="Stop Orphan Demo")
        self.btn_stop_orphan.get_style_context().add_class("btn-danger")
        self.btn_stop_orphan.set_sensitive(False)
        self.btn_stop_orphan.connect("clicked", self._on_stop_orphan)

        btn_box.pack_start(self.btn_spawn_orphan, True, True, 0)
        btn_box.pack_start(self.btn_stop_orphan, True, True, 0)
        panel.pack_start(btn_box, False, False, 4)

        return panel

    def _on_spawn_zombie(self, button):
        res = self.controller.spawn_zombie_demo()
        if res.get("status") == "success":
            self.btn_spawn_zombie.set_sensitive(False)
            self.btn_reap_zombie.set_sensitive(True)

    def _on_reap_zombie(self, button):
        self.controller.reap_zombie_demo()
        self.btn_spawn_zombie.set_sensitive(True)
        self.btn_reap_zombie.set_sensitive(False)

    def _on_spawn_orphan(self, button):
        res = self.controller.spawn_orphan_demo()
        if res.get("status") == "success":
            self.btn_spawn_orphan.set_sensitive(False)
            self.btn_stop_orphan.set_sensitive(True)

    def _on_stop_orphan(self, button):
        self.controller.stop_orphan_demo()
        self.btn_spawn_orphan.set_sensitive(True)
        self.btn_stop_orphan.set_sensitive(False)

    def _on_stop_all(self, button):
        self.controller.stop_all_demos()
        self.btn_spawn_zombie.set_sensitive(True)
        self.btn_reap_zombie.set_sensitive(False)
        self.btn_spawn_orphan.set_sensitive(True)
        self.btn_stop_orphan.set_sensitive(False)

    def update_demo_status(self):
        """Called periodically by the main window to update demo status cards."""
        z_status = self.controller.get_zombie_status()
        if z_status:
            self.zombie_status_lbl.set_markup(
                "<span color='#ef4444' weight='bold'>● ACTIVE ZOMBIE DETECTED</span>"
            )
            self.zombie_parent_lbl.set_markup(
                f"<span color='#94a3b8'>Parent PID:</span> <b>{z_status['parent_pid']}</b> (Sleeping without waitpid)"
            )
            self.zombie_child_lbl.set_markup(
                f"<span color='#94a3b8'>Zombie Child PID:</span> <b color='#ef4444'>{z_status['child_pid']}</b> (State 'Z' Defunct)"
            )
            self.zombie_time_lbl.set_markup(
                f"<span color='#94a3b8'>Active Time:</span> {z_status['elapsed_seconds']}s / 60s auto-timeout"
            )
            self.btn_spawn_zombie.set_sensitive(False)
            self.btn_reap_zombie.set_sensitive(True)
        else:
            self.zombie_status_lbl.set_markup("<b>Status:</b> Idle (No active zombie demo)")
            self.zombie_parent_lbl.set_markup("<span color='#94a3b8'>Parent PID:</span> -")
            self.zombie_child_lbl.set_markup("<span color='#94a3b8'>Zombie Child PID:</span> -")
            self.zombie_time_lbl.set_markup("<span color='#94a3b8'>Elapsed / Timeout:</span> -")
            self.btn_spawn_zombie.set_sensitive(True)
            self.btn_reap_zombie.set_sensitive(False)

        o_status = self.controller.get_orphan_status()
        if o_status:
            self.orphan_status_lbl.set_markup(
                "<span color='#f59e0b' weight='bold'>● ACTIVE ORPHAN DETECTED</span>"
            )
            self.orphan_old_parent_lbl.set_markup(
                f"<span color='#94a3b8'>Original Parent PID:</span> <b>{o_status['original_ppid']}</b> (Terminated & exited)"
            )
            self.orphan_child_lbl.set_markup(
                f"<span color='#94a3b8'>Orphan Child PID:</span> <b color='#f59e0b'>{o_status['child_pid']}</b> (Running)"
            )
            self.orphan_new_ppid_lbl.set_markup(
                f"<span color='#94a3b8'>Adopted By (PPID):</span> <b>PID {o_status['new_ppid']}</b> (init / systemd)"
            )
            self.btn_spawn_orphan.set_sensitive(False)
            self.btn_stop_orphan.set_sensitive(True)
        else:
            self.orphan_status_lbl.set_markup("<b>Status:</b> Idle (No active orphan demo)")
            self.orphan_old_parent_lbl.set_markup("<span color='#94a3b8'>Original Parent PID:</span> -")
            self.orphan_child_lbl.set_markup("<span color='#94a3b8'>Orphan Child PID:</span> -")
            self.orphan_new_ppid_lbl.set_markup("<span color='#94a3b8'>Adopted By (PPID):</span> -")
            self.btn_spawn_orphan.set_sensitive(True)
            self.btn_stop_orphan.set_sensitive(False)
