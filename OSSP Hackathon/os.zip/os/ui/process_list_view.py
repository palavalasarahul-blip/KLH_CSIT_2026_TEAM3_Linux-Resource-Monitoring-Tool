"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/process_list_view.py

Description:
    Complete interactive process explorer table. Supports instant search,
    state filtering (Running, Sleeping, Zombie, Orphan), sorting, and detailed
    inspection of process memory, command lines, and parentage.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import List, Dict, Any, Optional


class ProcessListView(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.set_border_width(20)

        self.all_processes: List[Dict[str, Any]] = []

        # 1. Top Controls Bar: Search & Filters
        controls_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

        # Title & Count
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='16' weight='bold' color='#f8fafc'>All System Processes</span>")
        self.count_lbl = Gtk.Label(xalign=0)
        self.count_lbl.set_markup("<span color='#94a3b8'>Showing 0 processes</span>")
        title_box.pack_start(title_lbl, False, False, 0)
        title_box.pack_start(self.count_lbl, False, False, 0)
        controls_box.pack_start(title_box, False, False, 0)

        # Spacer
        spacer = Gtk.Box()
        controls_box.pack_start(spacer, True, True, 0)

        # State Filter Dropdown
        filter_lbl = Gtk.Label(label="Filter:")
        self.filter_combo = Gtk.ComboBoxText()
        self.filter_combo.append("ALL", "All Processes")
        self.filter_combo.append("ZOMBIE", "🧟 Zombie Only (State Z)")
        self.filter_combo.append("ORPHAN", "🐣 Orphan Only")
        self.filter_combo.append("RUNNING", "Running Only (State R)")
        self.filter_combo.append("SLEEPING", "Sleeping Only (State S)")
        self.filter_combo.append("STOPPED", "Stopped Only (State T)")
        self.filter_combo.set_active(0)
        self.filter_combo.connect("changed", self._on_filter_changed)

        controls_box.pack_start(filter_lbl, False, False, 0)
        controls_box.pack_start(self.filter_combo, False, False, 0)

        # Search Entry
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Search PID, name, cmd...")
        self.search_entry.set_width_chars(25)
        self.search_entry.connect("search-changed", self._on_search_changed)
        controls_box.pack_start(self.search_entry, False, False, 0)

        self.pack_start(controls_box, False, False, 0)

        # 2. Main Process TreeView (Table)
        # Model schema:
        # 0: pid (int), 1: ppid (int), 2: name (str), 3: state (str),
        # 4: state_desc (str), 5: parent_name (str), 6: threads (int),
        # 7: memory_str (str), 8: user (str), 9: badge_markup (str), 10: raw_dict (object)
        self.list_store = Gtk.ListStore(int, int, str, str, str, str, int, str, str, str, object)

        # Filter model wrapper
        self.filter_model = self.list_store.filter_new()
        self.filter_model.set_visible_func(self._filter_func)

        # Sort model wrapper
        self.sort_model = Gtk.TreeModelSort(model=self.filter_model)
        self.tree_view = Gtk.TreeView(model=self.sort_model)
        self.tree_view.set_rules_hint(True)

        self._build_columns()

        # Selection handler
        self.selection = self.tree_view.get_selection()
        self.selection.connect("changed", self._on_selection_changed)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(350)
        scrolled.add(self.tree_view)
        self.pack_start(scrolled, True, True, 0)

        # 3. Process Details Panel (Bottom)
        self.detail_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.detail_panel.get_style_context().add_class("panel-card")

        self.detail_title = Gtk.Label(xalign=0)
        self.detail_title.set_markup("<span font='12' weight='bold' color='#f1f5f9'>Process Details</span> — Select a row to inspect full process attributes")
        self.detail_panel.pack_start(self.detail_title, False, False, 0)

        self.detail_grid = Gtk.Grid()
        self.detail_grid.set_column_spacing(24)
        self.detail_grid.set_row_spacing(4)

        self.lbl_cmd = Gtk.Label(xalign=0)
        self.lbl_cmd.set_line_wrap(True)
        self.lbl_cmd.set_selectable(True)
        self.lbl_cmd.set_markup("<span color='#94a3b8'>Command:</span> -")

        self.lbl_mem = Gtk.Label(xalign=0)
        self.lbl_mem.set_markup("<span color='#94a3b8'>Memory:</span> -")

        self.lbl_parent = Gtk.Label(xalign=0)
        self.lbl_parent.set_markup("<span color='#94a3b8'>Parent Info:</span> -")

        self.lbl_class = Gtk.Label(xalign=0)
        self.lbl_class.set_markup("<span color='#94a3b8'>Classification:</span> -")

        self.detail_grid.attach(self.lbl_cmd, 0, 0, 2, 1)
        self.detail_grid.attach(self.lbl_mem, 0, 1, 1, 1)
        self.detail_grid.attach(self.lbl_parent, 1, 1, 1, 1)
        self.detail_grid.attach(self.lbl_class, 0, 2, 2, 1)

        self.detail_panel.pack_start(self.detail_grid, False, False, 0)
        self.pack_start(self.detail_panel, False, False, 0)

    def _build_columns(self):
        # 0: PID
        renderer_pid = Gtk.CellRendererText()
        col_pid = Gtk.TreeViewColumn("PID", renderer_pid, text=0)
        col_pid.set_sort_column_id(0)
        col_pid.set_resizable(True)
        col_pid.set_min_width(70)
        self.tree_view.append_column(col_pid)

        # 1: PPID
        renderer_ppid = Gtk.CellRendererText()
        col_ppid = Gtk.TreeViewColumn("PPID", renderer_ppid, text=1)
        col_ppid.set_sort_column_id(1)
        col_ppid.set_resizable(True)
        col_ppid.set_min_width(70)
        self.tree_view.append_column(col_ppid)

        # 2: Name
        renderer_name = Gtk.CellRendererText()
        col_name = Gtk.TreeViewColumn("Process Name", renderer_name, text=2)
        col_name.set_sort_column_id(2)
        col_name.set_resizable(True)
        col_name.set_min_width(160)
        self.tree_view.append_column(col_name)

        # 3: State
        renderer_state = Gtk.CellRendererText()
        col_state = Gtk.TreeViewColumn("State", renderer_state, text=3)
        col_state.set_sort_column_id(3)
        col_state.set_min_width(60)
        self.tree_view.append_column(col_state)

        # 4: Parent Name
        renderer_pname = Gtk.CellRendererText()
        col_pname = Gtk.TreeViewColumn("Parent Process", renderer_pname, text=5)
        col_pname.set_sort_column_id(5)
        col_pname.set_resizable(True)
        col_pname.set_min_width(150)
        self.tree_view.append_column(col_pname)

        # 5: Threads
        renderer_th = Gtk.CellRendererText()
        col_th = Gtk.TreeViewColumn("Threads", renderer_th, text=6)
        col_th.set_sort_column_id(6)
        col_th.set_min_width(70)
        self.tree_view.append_column(col_th)

        # 6: Memory RSS
        renderer_mem = Gtk.CellRendererText()
        col_mem = Gtk.TreeViewColumn("Memory RSS", renderer_mem, text=7)
        col_mem.set_sort_column_id(7)
        col_mem.set_min_width(90)
        self.tree_view.append_column(col_mem)

        # 7: User
        renderer_usr = Gtk.CellRendererText()
        col_usr = Gtk.TreeViewColumn("User", renderer_usr, text=8)
        col_usr.set_sort_column_id(8)
        col_usr.set_min_width(80)
        self.tree_view.append_column(col_usr)

        # 8: Status Badge
        renderer_badge = Gtk.CellRendererText()
        col_badge = Gtk.TreeViewColumn("Classification", renderer_badge, markup=9)
        col_badge.set_resizable(True)
        col_badge.set_min_width(140)
        self.tree_view.append_column(col_badge)

    def _filter_func(self, model, iter, data):
        query = self.search_entry.get_text().strip().lower()
        filter_type = self.filter_combo.get_active_id()

        pid = model[iter][0]
        name = model[iter][2].lower()
        state = model[iter][3].upper()
        pname = model[iter][5].lower()
        p_dict = model[iter][10]

        is_zombie = p_dict.get("is_zombie", False)
        is_orphan = p_dict.get("is_orphan", False)

        # Category check
        if filter_type == "ZOMBIE" and not is_zombie:
            return False
        elif filter_type == "ORPHAN" and not is_orphan:
            return False
        elif filter_type == "RUNNING" and state != "R":
            return False
        elif filter_type == "SLEEPING" and state not in ("S", "D"):
            return False
        elif filter_type == "STOPPED" and state not in ("T", "t"):
            return False

        # Text search check
        if query:
            if query not in str(pid) and query not in name and query not in pname and query not in p_dict.get("cmdline", "").lower():
                return False

        return True

    def _on_search_changed(self, entry):
        self.filter_model.refilter()
        self._update_count()

    def _on_filter_changed(self, combo):
        self.filter_model.refilter()
        self._update_count()

    def _on_selection_changed(self, selection):
        model, iter = selection.get_selected()
        if iter:
            # Map back to child model to fetch dictionary
            child_iter = self.sort_model.convert_iter_to_child_iter(iter)
            grandchild_iter = self.filter_model.convert_iter_to_child_iter(child_iter)
            p_dict = self.list_store[grandchild_iter][10]

            self.detail_title.set_markup(
                f"<span font='12' weight='bold' color='#f1f5f9'>PID {p_dict['pid']} — {p_dict['name']}</span> "
                f"<span color='#94a3b8'>({p_dict['state_desc']})</span>"
            )

            cmd = p_dict.get("cmdline", f"[{p_dict['name']}]")
            self.lbl_cmd.set_markup(f"<span color='#94a3b8'>Command:</span> <tt>{cmd}</tt>")

            vmsize = p_dict.get("vmsize_kb", 0)
            vmrss = p_dict.get("vmrss_kb", 0)
            self.lbl_mem.set_markup(f"<span color='#94a3b8'>Memory:</span> RSS: {vmrss / 1024:.1f} MB | VmSize: {vmsize / 1024:.1f} MB | UID: {p_dict.get('uid', 0)} ({p_dict.get('user', 'root')})")

            pname = p_dict.get("parent_name", "unknown")
            ppid = p_dict.get("ppid", 0)
            self.lbl_parent.set_markup(f"<span color='#94a3b8'>Parent:</span> {pname} (PID {ppid})")

            classification = p_dict.get("classification", "Normal Process")
            detail = p_dict.get("classification_detail", "")
            self.lbl_class.set_markup(f"<span color='#94a3b8'>Status:</span> <b>{classification}</b> — {detail}")

    def _update_count(self):
        visible = 0
        iter = self.filter_model.get_iter_first()
        while iter:
            visible += 1
            iter = self.filter_model.iter_next(iter)
        self.count_lbl.set_markup(f"<span color='#94a3b8'>Showing {visible} of {len(self.all_processes)} processes</span>")

    def update_processes(self, processes: List[Dict[str, Any]]):
        """Refreshes the table data with a new process snapshot."""
        self.all_processes = processes

        # Save selected PID
        selected_pid = None
        model, iter = self.selection.get_selected()
        if iter:
            selected_pid = model[iter][0]

        self.list_store.clear()

        for p in processes:
            pid = p["pid"]
            ppid = p["ppid"]
            name = p["name"]
            state = p["state"]
            state_desc = p.get("state_desc", "Unknown")
            parent_name = p.get("parent_name", "unknown")
            threads = p.get("threads", 1)
            vmrss_kb = p.get("vmrss_kb", 0)
            memory_str = f"{vmrss_kb / 1024:.1f} MB" if vmrss_kb > 0 else "0.0 MB"
            user = p.get("user", "root")

            is_zombie = p.get("is_zombie", False)
            is_orphan = p.get("is_orphan", False)

            if is_zombie:
                badge = "<span background='#ef4444' color='#ffffff' weight='bold'> ZOMBIE </span>"
            elif is_orphan:
                badge = "<span background='#f59e0b' color='#000000' weight='bold'> ORPHAN </span>"
            elif state == 'R':
                badge = "<span background='#10b981' color='#ffffff'> Running </span>"
            elif ppid == 1:
                badge = "<span background='#334155' color='#94a3b8'> System Daemon </span>"
            else:
                badge = "<span background='#1e293b' color='#cbd5e1'> Normal </span>"

            self.list_store.append([
                pid, ppid, name, state, state_desc, parent_name,
                threads, memory_str, user, badge, p
            ])

        self.filter_model.refilter()
        self._update_count()
