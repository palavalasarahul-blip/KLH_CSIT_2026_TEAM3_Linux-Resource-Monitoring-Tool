"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/zombie_view.py

Description:
    Dedicated Zombie Process Detection and Diagnostic View.
    Displays all detected defunct processes (State 'Z' in /proc/[pid]/stat)
    with highlighted red indicators, parent process tracing, and remediation hints.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import List, Dict, Any, Callable, Optional


class ZombieView(Gtk.Box):
    def __init__(self, navigation_callback: Optional[Callable[[str], None]] = None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.set_border_width(20)
        self.navigation_callback = navigation_callback
        self.current_zombies: List[Dict[str, Any]] = []

        # 1. Header Box
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='18' weight='bold' color='#ef4444'>🧟 Zombie Process Detection</span>")
        subtitle_lbl = Gtk.Label(xalign=0)
        subtitle_lbl.set_markup("<span color='#94a3b8'>Real-time inspection of defunct processes awaiting parent waitpid()</span>")
        header_box.pack_start(title_lbl, False, False, 0)
        header_box.pack_start(subtitle_lbl, False, False, 0)
        self.pack_start(header_box, False, False, 0)

        # 2. Operating System Concept Explanation Card
        theory_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        theory_card.get_style_context().add_class("panel-card")
        theory_card.get_style_context().add_class("metric-card-zombie")

        theory_title = Gtk.Label(xalign=0)
        theory_title.set_markup("<span font='13' weight='bold' color='#f87171'>Operating Systems Concept: The Zombie (Defunct) State</span>")

        theory_body = Gtk.Label(xalign=0)
        theory_body.set_line_wrap(True)
        theory_body.set_markup(
            "<span color='#cbd5e1'>When a child process terminates via <tt>exit()</tt>, its virtual memory, files, and resources are deallocated immediately. "
            "However, its <b>Process Control Block (PCB)</b> and entry in the kernel process table are retained so that the parent can retrieve its exit status and resource metrics via <tt>wait()</tt> or <tt>waitpid()</tt>.\n\n"
            "If the parent process does not call <tt>waitpid()</tt>, the child remains permanently in state <b>'Z' (Zombie)</b>. While zombies consume negligible RAM, they occupy <b>Process IDs (PIDs)</b> from the operating system's finite PID namespace.</span>"
        )
        theory_card.pack_start(theory_title, False, False, 0)
        theory_card.pack_start(theory_body, False, False, 0)
        self.pack_start(theory_card, False, False, 0)

        # 3. Action Bar
        action_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.count_badge = Gtk.Label(xalign=0)
        self.count_badge.set_markup("<span font='13' weight='bold' color='#f8fafc'>Detected Zombies: 0</span>")
        action_bar.pack_start(self.count_badge, False, False, 0)

        spacer = Gtk.Box()
        action_bar.pack_start(spacer, True, True, 0)

        btn_demo = Gtk.Button(label="🧪 Create Zombie in Demonstration Lab")
        btn_demo.get_style_context().add_class("btn-danger")
        btn_demo.connect("clicked", lambda b: self._navigate("demo"))
        action_bar.pack_start(btn_demo, False, False, 0)

        self.pack_start(action_bar, False, False, 0)

        # 4. Zombie Process Table
        # Columns: 0: PID, 1: PPID, 2: Name, 3: State, 4: Parent Name, 5: Detection Status, 6: Raw dict
        self.list_store = Gtk.ListStore(int, int, str, str, str, str, object)
        self.tree_view = Gtk.TreeView(model=self.list_store)
        self.tree_view.set_rules_hint(True)

        self._build_columns()

        # Scrolled window
        self.scrolled = Gtk.ScrolledWindow()
        self.scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.scrolled.set_min_content_height(250)
        self.scrolled.add(self.tree_view)
        self.pack_start(self.scrolled, True, True, 0)

        # 5. Empty State Container
        self.empty_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.empty_box.get_style_context().add_class("panel-card")
        empty_lbl = Gtk.Label()
        empty_lbl.set_markup(
            "<span font='14' weight='bold' color='#10b981'>✓ Zero Zombie Processes Detected</span>\n"
            "<span color='#94a3b8'>All child processes are properly reaped by their parents or init. Use the Demonstration Lab to safely create and analyze a live zombie.</span>"
        )
        empty_lbl.set_justify(Gtk.Justification.CENTER)
        self.empty_box.pack_start(empty_lbl, True, True, 16)
        self.pack_start(self.empty_box, False, False, 0)

    def _build_columns(self):
        # PID
        r_pid = Gtk.CellRendererText()
        col_pid = Gtk.TreeViewColumn("Zombie PID", r_pid, text=0)
        col_pid.set_min_width(90)
        self.tree_view.append_column(col_pid)

        # PPID
        r_ppid = Gtk.CellRendererText()
        col_ppid = Gtk.TreeViewColumn("Parent PID", r_ppid, text=1)
        col_ppid.set_min_width(90)
        self.tree_view.append_column(col_ppid)

        # Name
        r_name = Gtk.CellRendererText()
        col_name = Gtk.TreeViewColumn("Process Name", r_name, text=2)
        col_name.set_min_width(180)
        self.tree_view.append_column(col_name)

        # State Indicator
        r_state = Gtk.CellRendererText()
        col_state = Gtk.TreeViewColumn("State", r_state, text=3)
        col_state.set_min_width(70)
        self.tree_view.append_column(col_state)

        # Parent Process Name
        r_pname = Gtk.CellRendererText()
        col_pname = Gtk.TreeViewColumn("Parent Name", r_pname, text=4)
        col_pname.set_min_width(180)
        self.tree_view.append_column(col_pname)

        # Detection Status
        r_status = Gtk.CellRendererText()
        col_status = Gtk.TreeViewColumn("Status / Diagnostic", r_status, markup=5)
        col_status.set_min_width(260)
        self.tree_view.append_column(col_status)

    def _navigate(self, page_id: str):
        if self.navigation_callback:
            self.navigation_callback(page_id)

    def update_zombies(self, zombies: List[Dict[str, Any]]):
        self.current_zombies = zombies
        self.list_store.clear()

        count = len(zombies)
        self.count_badge.set_markup(
            f"<span font='13' weight='bold' color='{'#ef4444' if count > 0 else '#10b981'}'>Detected Zombies: {count}</span>"
        )

        if count == 0:
            self.scrolled.hide()
            self.empty_box.show_all()
        else:
            self.empty_box.hide()
            self.scrolled.show_all()

            for z in zombies:
                status_markup = (
                    f"<span color='#f87171' weight='bold'>Defunct (State Z)</span> — "
                    f"Awaiting waitpid() from Parent {z.get('parent_name', 'PID ' + str(z['ppid']))}"
                )
                self.list_store.append([
                    z["pid"], z["ppid"], z["name"], z["state"],
                    z.get("parent_name", "unknown"), status_markup, z
                ])
