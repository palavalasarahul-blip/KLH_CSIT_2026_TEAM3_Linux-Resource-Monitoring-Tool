"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/tree_view.py

Description:
    Hierarchical process tree viewer powered by GTK TreeStore.
    Visualizes the entire parent-child process tree structure anchored at
    PID 1 (systemd/init) and displays anomalous zombie and orphan nodes.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango
from typing import List, Dict, Any, Optional
import process_tree


class ProcessTreeView(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.set_border_width(20)

        # 1. Header and Controls
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='16' weight='bold' color='#f8fafc'>Process Hierarchy Tree</span>")
        self.status_lbl = Gtk.Label(xalign=0)
        self.status_lbl.set_markup("<span color='#94a3b8'>Tree rooted at init (PID 1)</span>")
        title_box.pack_start(title_lbl, False, False, 0)
        title_box.pack_start(self.status_lbl, False, False, 0)
        header_box.pack_start(title_box, False, False, 0)

        spacer = Gtk.Box()
        header_box.pack_start(spacer, True, True, 0)

        # Toolbar Buttons
        btn_expand = Gtk.Button(label="Expand All")
        btn_expand.connect("clicked", lambda b: self.tree_view.expand_all())

        btn_collapse = Gtk.Button(label="Collapse All")
        btn_collapse.connect("clicked", lambda b: self.tree_view.collapse_all())

        btn_find_anomaly = Gtk.Button(label="🔍 Locate Zombie / Orphan")
        btn_find_anomaly.get_style_context().add_class("btn-warning")
        btn_find_anomaly.connect("clicked", self._on_locate_anomaly)

        header_box.pack_start(btn_expand, False, False, 0)
        header_box.pack_start(btn_collapse, False, False, 0)
        header_box.pack_start(btn_find_anomaly, False, False, 0)

        self.pack_start(header_box, False, False, 0)

        # 2. Legend Strip
        legend_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        legend_box.get_style_context().add_class("panel-card")
        legend_box.set_margin_bottom(4)

        leg_title = Gtk.Label(xalign=0)
        leg_title.set_markup("<span font='11' weight='bold' color='#64748b'>LEGEND:</span>")
        legend_box.pack_start(leg_title, False, False, 0)

        leg_zombie = Gtk.Label(xalign=0)
        leg_zombie.set_markup("<span background='#ef4444' color='#ffffff' weight='bold'> RED </span> Zombie (Defunct)")
        legend_box.pack_start(leg_zombie, False, False, 0)

        leg_orphan = Gtk.Label(xalign=0)
        leg_orphan.set_markup("<span background='#f59e0b' color='#000000' weight='bold'> ORANGE </span> Reparented Orphan")
        legend_box.pack_start(leg_orphan, False, False, 0)

        leg_run = Gtk.Label(xalign=0)
        leg_run.set_markup("<span background='#10b981' color='#ffffff'> GREEN </span> Running")
        legend_box.pack_start(leg_run, False, False, 0)

        leg_norm = Gtk.Label(xalign=0)
        leg_norm.set_markup("<span background='#334155' color='#94a3b8'> GRAY </span> Sleeping / Standard")
        legend_box.pack_start(leg_norm, False, False, 0)

        self.pack_start(legend_box, False, False, 0)

        # 3. Main Tree View with TreeStore
        # Schema:
        # 0: formatted_markup (str)
        # 1: pid (int)
        # 2: ppid (int)
        # 3: state (str)
        # 4: descendants_str (str)
        # 5: badge_markup (str)
        # 6: is_anomaly (bool)
        self.tree_store = Gtk.TreeStore(str, int, int, str, str, str, bool)
        self.tree_view = Gtk.TreeView(model=self.tree_store)
        self.tree_view.set_rules_hint(True)

        self._build_columns()

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(450)
        scrolled.add(self.tree_view)
        self.pack_start(scrolled, True, True, 0)

    def _build_columns(self):
        # Tree hierarchy column
        r_tree = Gtk.CellRendererText()
        col_tree = Gtk.TreeViewColumn("Process Tree (Name & PID)", r_tree, markup=0)
        col_tree.set_min_width(320)
        col_tree.set_resizable(True)
        self.tree_view.append_column(col_tree)

        # State column
        r_state = Gtk.CellRendererText()
        col_state = Gtk.TreeViewColumn("State", r_state, text=3)
        col_state.set_min_width(70)
        self.tree_view.append_column(col_state)

        # Subtree descendants count
        r_desc = Gtk.CellRendererText()
        col_desc = Gtk.TreeViewColumn("Children / Subtree", r_desc, text=4)
        col_desc.set_min_width(120)
        self.tree_view.append_column(col_desc)

        # Badge column
        r_badge = Gtk.CellRendererText()
        col_badge = Gtk.TreeViewColumn("Status Indicator", r_badge, markup=5)
        col_badge.set_min_width(180)
        self.tree_view.append_column(col_badge)

    def _on_locate_anomaly(self, button):
        """Finds and expands the first zombie or orphan node in the tree."""
        def search_iter(iter):
            while iter:
                is_anomaly = self.tree_store[iter][6]
                if is_anomaly:
                    path = self.tree_store.get_path(iter)
                    self.tree_view.expand_to_path(path)
                    self.tree_view.get_selection().select_path(path)
                    self.tree_view.scroll_to_cell(path, None, True, 0.5, 0.0)
                    return True
                child = self.tree_store.iter_children(iter)
                if child and search_iter(child):
                    return True
                iter = self.tree_store.iter_next(iter)
            return False

        first_root = self.tree_store.get_iter_first()
        found = search_iter(first_root)
        if not found:
            self.status_lbl.set_markup("<span color='#10b981'>No anomalies (zombies/orphans) found in the process tree.</span>")

    def update_tree(self, processes: List[Dict[str, Any]]):
        """Reconstructs and populates the GTK TreeStore."""
        roots = process_tree.ProcessTreeBuilder.build_tree(processes)
        self.tree_store.clear()

        anomaly_count = 0

        def add_node_recursive(node: process_tree.ProcessTreeNode, parent_iter):
            nonlocal anomaly_count
            name = node.name
            pid = node.pid
            ppid = node.ppid
            state = node.state
            descendants = node.total_descendants

            is_zombie = node.is_zombie
            is_orphan = node.is_orphan
            is_anomaly = is_zombie or is_orphan

            if is_anomaly:
                anomaly_count += 1

            if is_zombie:
                text_markup = f"<span color='#ef4444' weight='bold'>🧟 {name}</span> <span font_family='monospace' color='#f87171'>(PID {pid})</span>"
                badge = "<span background='#ef4444' color='#ffffff' weight='bold'> ZOMBIE PROCESS </span>"
            elif is_orphan:
                text_markup = f"<span color='#f59e0b' weight='bold'>🐣 {name}</span> <span font_family='monospace' color='#fbbf24'>(PID {pid})</span>"
                badge = "<span background='#f59e0b' color='#000000' weight='bold'> REPARENTED ORPHAN </span>"
            elif state == 'R':
                text_markup = f"<span color='#34d399' weight='bold'>{name}</span> <span font_family='monospace' color='#94a3b8'>(PID {pid})</span>"
                badge = "<span color='#10b981'>Running</span>"
            else:
                text_markup = f"<span color='#f1f5f9'>{name}</span> <span font_family='monospace' color='#94a3b8'>(PID {pid})</span>"
                badge = f"<span color='#64748b'>{node.state_desc}</span>"

            desc_str = f"{len(node.children)} direct ({descendants} total)" if descendants > 0 else "0 (leaf)"

            current_iter = self.tree_store.append(parent_iter, [
                text_markup, pid, ppid, state, desc_str, badge, is_anomaly
            ])

            for child in node.children:
                add_node_recursive(child, current_iter)

        for root in roots:
            add_node_recursive(root, None)

        # Expand root level by default
        self.tree_view.expand_row(Gtk.TreePath.new_first(), False)
        self.status_lbl.set_markup(
            f"<span color='#94a3b8'>Tree populated: {len(processes)} processes | Anomaly nodes: <b>{anomaly_count}</b></span>"
        )
