"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: ui/about_view.py

Description:
    Academic documentation and theoretical guide suitable for B.Tech
    Operating Systems project presentations and vivas.
===============================================================================
"""

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Pango


class AboutView(Gtk.ScrolledWindow):
    def __init__(self):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.set_border_width(20)

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)

        # 1. Title Banner
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_lbl = Gtk.Label(xalign=0)
        title_lbl.set_markup("<span font='20' weight='bold' color='#f8fafc'>Zombie &amp; Orphan Process Detection System</span>")
        sub_lbl = Gtk.Label(xalign=0)
        sub_lbl.set_markup("<span color='#38bdf8' weight='bold'>B.Tech Computer Science &amp; Engineering — Operating Systems Project</span>")
        title_box.pack_start(title_lbl, False, False, 0)
        title_box.pack_start(sub_lbl, False, False, 0)
        main_box.pack_start(title_box, False, False, 0)

        # 2. Key Differences Table Card
        comp_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        comp_card.get_style_context().add_class("panel-card")

        comp_title = Gtk.Label(xalign=0)
        comp_title.set_markup("<span font='14' weight='bold' color='#f1f5f9'>📊 Zombie vs. Orphan Process: Core OS Differences</span>")
        comp_card.pack_start(comp_title, False, False, 0)

        # Create structured comparison table
        comp_grid = Gtk.Grid()
        comp_grid.set_column_spacing(16)
        comp_grid.set_row_spacing(10)

        headers = ["Dimension", "Zombie Process (Defunct)", "Orphan Process"]
        for col_idx, h in enumerate(headers):
            lbl = Gtk.Label(xalign=0)
            lbl.set_markup(f"<span font='11' weight='bold' color='#64748b'>{h.upper()}</span>")
            comp_grid.attach(lbl, col_idx, 0, 1, 1)

        rows = [
            ("Process State", "<span color='#f87171' weight='bold'>Terminated (Dead)</span>, State 'Z'", "<span color='#fbbf24' weight='bold'>Executing (Alive)</span>, State 'S' or 'R'"),
            ("Condition", "Child has called exit(); parent has not called wait()", "Parent has terminated; child continues execution"),
            ("Parent Identity", "Still belongs to original parent", "Original parent lost; reparented to init (PID 1)"),
            ("Resource Consumption", "Consumes NO CPU or RAM; occupies 1 PID slot", "Consumes CPU, RAM, file descriptors like normal"),
            ("Kernel Handling", "Kernel preserves exit status in Process Control Block", "Kernel reparents child to nearest subreaper or init"),
            ("Resolution / Fix", "Parent must call wait() / waitpid() or parent killed", "Automatically reaped by init when child eventually exits"),
            ("Danger to OS", "PID exhaustion if parent leaks thousands of zombies", "Generally harmless; init safely harvests on exit")
        ]

        for row_idx, r in enumerate(rows, start=1):
            for col_idx, text in enumerate(r):
                lbl = Gtk.Label(xalign=0)
                lbl.set_line_wrap(True)
                lbl.set_markup(f"<span color='#cbd5e1'>{text}</span>")
                comp_grid.attach(lbl, col_idx, row_idx, 1, 1)

        comp_card.pack_start(comp_grid, False, False, 4)
        main_box.pack_start(comp_card, False, False, 0)

        # 3. System Architecture & Mechanics Card
        arch_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        arch_card.get_style_context().add_class("panel-card")

        arch_title = Gtk.Label(xalign=0)
        arch_title.set_markup("<span font='14' weight='bold' color='#f1f5f9'>⚙️ Technical Implementation &amp; Linux Architecture</span>")
        arch_card.pack_start(arch_title, False, False, 0)

        arch_text = Gtk.Label(xalign=0)
        arch_text.set_line_wrap(True)
        arch_text.set_markup(
            "<span color='#cbd5e1'>"
            "<b>1. Linux /proc Filesystem Traversal:</b>\n"
            "The system reads process state directly from <tt>/proc/[pid]/stat</tt>. Because process command names (<tt>comm</tt>) "
            "can legally contain spaces and nested parentheses (e.g. <tt>(Web Content)</tt>), standard <tt>sscanf</tt> parsing fails. "
            "Our C backend implements the POSIX-compliant approach: locating the <i>first</i> <tt>'('</tt> and the <i>last</i> <tt>')'</tt> "
            "in the line to guarantee crash-proof extraction.\n\n"
            "<b>2. Dynamic Genealogy Tracking:</b>\n"
            "Linux does not preserve history of dead parents in process snapshots. To avoid incorrectly classifying system daemons (which naturally run with PPID 1) as orphans, "
            "our Python engine maintains a process genealogy history over time. A process is marked as an orphan only when its original non-init parent is observed terminating.\n\n"
            "<b>3. Controlled Demonstration Engine:</b>\n"
            "Written in standard C99/C11 using <tt>fork()</tt>, <tt>exit()</tt>, <tt>waitpid()</tt>, and POSIX signals (<tt>SIGUSR1</tt>, <tt>SIGALRM</tt>). "
            "Safety timers guarantee zero leftover processes."
            "</span>"
        )
        arch_card.pack_start(arch_text, False, False, 0)
        main_box.pack_start(arch_card, False, False, 0)

        # 4. Technologies & Tools Card
        tech_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        tech_card.get_style_context().add_class("panel-card")

        tech_title = Gtk.Label(xalign=0)
        tech_title.set_markup("<span font='14' weight='bold' color='#f1f5f9'>🛠️ Technology Stack &amp; Standards</span>")
        tech_card.pack_start(tech_title, False, False, 0)

        tech_text = Gtk.Label(xalign=0)
        tech_text.set_line_wrap(True)
        tech_text.set_markup(
            "<span color='#cbd5e1'>"
            "• <b>Backend Engine:</b> C (GCC 13, C11 Standard) — zero external library dependencies, direct Linux syscalls\n"
            "• <b>Desktop UI:</b> Python 3.12 with GTK 3 (PyGObject) — native Linux desktop GUI\n"
            "• <b>Process Communication:</b> Standard POSIX pipes and JSON serialization\n"
            "• <b>Target Operating System:</b> Ubuntu Linux (Kernel 6.x) with systemd init\n"
            "• <b>Build Automation:</b> GNU Makefile with <tt>make</tt>, <tt>make run</tt>, <tt>make test</tt>, <tt>make clean</tt>"
            "</span>"
        )
        tech_card.pack_start(tech_text, False, False, 0)
        main_box.pack_start(tech_card, False, False, 0)

        self.add(main_box)
