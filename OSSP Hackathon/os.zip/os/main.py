#!/usr/bin/env python3
"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: main.py

Description:
    Main entry point for the Linux GTK 3 desktop application.
    Constructs the application window, sidebar navigation, top control header,
    loads the custom dark CSS styling, coordinates live process monitoring,
    and guarantees leak-free shutdown of all demonstration processes.

Usage:
    python3 main.py
    or via Makefile:
    make run
===============================================================================
"""

import os
import sys
import signal

# Ensure project root is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk, GLib

import process_monitor
import demo_controller

from ui.dashboard_view import DashboardView
from ui.process_list_view import ProcessListView
from ui.zombie_view import ZombieView
from ui.orphan_view import OrphanView
from ui.tree_view import ProcessTreeView
from ui.demo_view import DemonstrationView
from ui.log_view import EventLogView
from ui.about_view import AboutView


class MainWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Zombie & Orphan Process Detection System")
        self.set_default_size(1180, 750)
        self.set_position(Gtk.WindowPosition.CENTER)

        # Load custom CSS
        self._load_css()

        # Initialize core monitoring and demo engines
        self.monitor = process_monitor.ProcessMonitor()
        self.controller = demo_controller.DemoController(
            monitor=self.monitor,
            event_logger=self.on_log_event
        )

        self.monitoring_active = True
        self.refresh_interval_sec = 2

        # Anomaly tracking to prevent log spamming
        self._prev_zombie_pids = set()
        self._prev_orphan_pids = set()

        # Construct UI Layout
        self._build_ui()

        # Connect window close handlers
        self.connect("delete-event", self._on_window_close)

        # Start periodic monitoring timer
        self.timer_id = GLib.timeout_add_seconds(self.refresh_interval_sec, self._on_timer_tick)

        # Initial scan and load
        self.on_log_event("info", "Zombie & Orphan Process Detection System initialized.")
        self.on_log_event("info", "Linux /proc filesystem scanner active. Live monitoring started (2s interval).")
        self.refresh_data()

    def _load_css(self):
        css_path = os.path.join(BASE_DIR, "ui", "style.css")
        if os.path.exists(css_path):
            provider = Gtk.CssProvider()
            try:
                provider.load_from_path(css_path)
                screen = Gdk.Screen.get_default()
                if screen:
                    Gtk.StyleContext.add_provider_for_screen(
                        screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
                    )
            except Exception as e:
                print(f"[Warning] Failed to load CSS styles: {e}", file=sys.stderr)

    def _build_ui(self):
        root_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # 1. HeaderBar
        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.set_title("Zombie & Orphan Process Detection System")
        header.set_subtitle("Linux Operating Systems Project")

        # Top Control: Live Monitoring Switch
        self.btn_toggle_monitor = Gtk.Button(label="⏹ Pause Monitoring")
        self.btn_toggle_monitor.connect("clicked", self._on_toggle_monitoring)
        header.pack_start(self.btn_toggle_monitor)

        # Top Control: Manual Refresh
        btn_refresh = Gtk.Button(label="🔄 Refresh Now")
        btn_refresh.connect("clicked", lambda b: self.refresh_data())
        header.pack_start(btn_refresh)

        # Top Control: Quick Stop Demos
        btn_stop_demos = Gtk.Button(label="🧹 Stop All Demos")
        btn_stop_demos.get_style_context().add_class("btn-danger")
        btn_stop_demos.connect("clicked", lambda b: self.controller.stop_all_demos())
        header.pack_end(btn_stop_demos)

        self.set_titlebar(header)

        # 2. Main Horizontal Split (Sidebar + Stack)
        main_hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)

        # Sidebar
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        sidebar.get_style_context().add_class("sidebar")
        sidebar.set_size_request(220, -1)

        brand_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        brand_box.set_margin_bottom(12)
        brand_box.set_margin_top(6)
        brand_box.set_margin_start(10)
        brand_title = Gtk.Label(xalign=0)
        brand_title.set_markup("<span font='14' weight='bold' color='#38bdf8'>PROCESS DETECTOR</span>")
        brand_sub = Gtk.Label(xalign=0)
        brand_sub.set_markup("<span font='10' color='#64748b'>OS LAB SUITE</span>")
        brand_box.pack_start(brand_title, False, False, 0)
        brand_box.pack_start(brand_sub, False, False, 0)
        sidebar.pack_start(brand_box, False, False, 0)

        nav_header = Gtk.Label(xalign=0)
        nav_header.set_markup("<span font='10' weight='bold' color='#64748b'>NAVIGATION</span>")
        sidebar.pack_start(nav_header, False, False, 0)

        # Navigation Buttons
        self.nav_buttons = {}
        nav_items = [
            ("dashboard", "📊 Dashboard"),
            ("processes", "📋 All Processes"),
            ("zombies", "🧟 Zombie Processes"),
            ("orphans", "🐣 Orphan Processes"),
            ("tree", "🌲 Process Tree"),
            ("demo", "🧪 Demonstrations"),
            ("log", "📜 Event Log"),
            ("about", "ℹ️ About Project"),
        ]

        for page_id, label in nav_items:
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("sidebar-button")
            btn.set_alignment(0.0, 0.5)
            btn.connect("clicked", self._create_nav_handler(page_id))
            sidebar.pack_start(btn, False, False, 0)
            self.nav_buttons[page_id] = btn

        # Spacer to push footer to bottom
        sidebar_spacer = Gtk.Box()
        sidebar.pack_start(sidebar_spacer, True, True, 0)

        # Sidebar Footer
        footer_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        footer_box.set_margin_start(10)
        footer_box.set_margin_bottom(10)
        self.footer_status = Gtk.Label(xalign=0)
        self.footer_status.set_markup("<span font='11' color='#10b981'>● Monitoring Active</span>")
        footer_box.pack_start(self.footer_status, False, False, 0)
        sidebar.pack_start(footer_box, False, False, 0)

        main_hbox.pack_start(sidebar, False, False, 0)

        # Content Stack
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self.stack.set_transition_duration(150)

        # Instantiate View Pages
        self.dashboard_view = DashboardView(navigation_callback=self.navigate_to)
        self.process_list_view = ProcessListView()
        self.zombie_view = ZombieView(navigation_callback=self.navigate_to)
        self.orphan_view = OrphanView(navigation_callback=self.navigate_to)
        self.tree_view = ProcessTreeView()
        self.demo_view = DemonstrationView(controller=self.controller)
        self.log_view = EventLogView()
        self.about_view = AboutView()

        self.stack.add_named(self.dashboard_view, "dashboard")
        self.stack.add_named(self.process_list_view, "processes")
        self.stack.add_named(self.zombie_view, "zombies")
        self.stack.add_named(self.orphan_view, "orphans")
        self.stack.add_named(self.tree_view, "tree")
        self.stack.add_named(self.demo_view, "demo")
        self.stack.add_named(self.log_view, "log")
        self.stack.add_named(self.about_view, "about")

        main_hbox.pack_start(self.stack, True, True, 0)

        root_vbox.pack_start(main_hbox, True, True, 0)
        self.add(root_vbox)

        # Highlight default page
        self.navigate_to("dashboard")

    def _create_nav_handler(self, page_id: str):
        return lambda btn: self.navigate_to(page_id)

    def navigate_to(self, page_id: str):
        """Switches the active content view and updates sidebar highlights."""
        if page_id in self.nav_buttons:
            self.stack.set_visible_child_name(page_id)
            for pid, btn in self.nav_buttons.items():
                sc = btn.get_style_context()
                if pid == page_id:
                    sc.add_class("active")
                else:
                    sc.remove_class("active")

    def _on_toggle_monitoring(self, button):
        self.monitoring_active = not self.monitoring_active
        if self.monitoring_active:
            self.btn_toggle_monitor.set_label("⏹ Pause Monitoring")
            self.footer_status.set_markup("<span font='11' color='#10b981'>● Monitoring Active</span>")
            self.on_log_event("info", "Process monitoring resumed by user.")
            self.refresh_data()
        else:
            self.btn_toggle_monitor.set_label("▶ Resume Monitoring")
            self.footer_status.set_markup("<span font='11' color='#64748b'>○ Monitoring Paused</span>")
            self.on_log_event("info", "Process monitoring paused by user.")

    def _on_timer_tick(self):
        """Periodic background callback triggered every refresh_interval_sec."""
        if self.monitoring_active:
            try:
                self.refresh_data()
            except Exception as e:
                print(f"[Error] Refresh failed during timer tick: {e}", file=sys.stderr)
        return True  # Return True to keep the timer firing

    def refresh_data(self):
        """Scans the system process table, classifies states, and updates all views."""
        processes = self.monitor.scan_processes()
        summary = self.monitor.last_summary
        zombies = self.monitor.last_zombies
        orphans = self.monitor.last_orphans

        # Check for new or removed zombies for logging
        current_zombie_pids = {z["pid"] for z in zombies}
        new_zombies = current_zombie_pids - self._prev_zombie_pids
        for zpid in new_zombies:
            matching = [z for z in zombies if z["pid"] == zpid]
            name = matching[0]["name"] if matching else "unknown"
            ppid = matching[0]["ppid"] if matching else 0
            self.on_log_event("alert", f"Zombie process detected: PID {zpid} ({name}) awaiting waitpid() from Parent PID {ppid}!")

        reaped_zombies = self._prev_zombie_pids - current_zombie_pids
        for rpid in reaped_zombies:
            self.on_log_event("info", f"Zombie PID {rpid} has been reaped and released from the process table.")

        self._prev_zombie_pids = current_zombie_pids

        # Check for new orphans for logging
        current_orphan_pids = {o["pid"] for o in orphans}
        new_orphans = current_orphan_pids - self._prev_orphan_pids
        for opid in new_orphans:
            matching = [o for o in orphans if o["pid"] == opid]
            name = matching[0]["name"] if matching else "unknown"
            reason = matching[0].get("orphan_reason", "Adopted by init")
            self.on_log_event("alert", f"Orphan process detected: PID {opid} ({name}) — {reason}")

        self._prev_orphan_pids = current_orphan_pids

        # Update views
        self.dashboard_view.update_view(summary, zombies, orphans)
        self.process_list_view.update_processes(processes)
        self.zombie_view.update_zombies(zombies)
        self.orphan_view.update_orphans(orphans)
        self.tree_view.update_tree(processes)
        self.demo_view.update_demo_status()

    def on_log_event(self, level: str, message: str):
        """Dispatches log events to the EventLogView and console."""
        if hasattr(self, 'log_view') and self.log_view:
            self.log_view.add_entry(level, message)
        else:
            print(f"[{level.upper()}] {message}")

    def _on_window_close(self, widget, event):
        """Ensures all demonstration processes and timers are safely terminated."""
        print("[Shutdown] Closing application. Terminating demonstration processes...")
        if hasattr(self, 'timer_id') and self.timer_id:
            GLib.source_remove(self.timer_id)
        if hasattr(self, 'controller') and self.controller:
            self.controller.stop_all_demos()
        Gtk.main_quit()
        return False


def main():
    # Handle CTRL+C cleanly
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    # Initialize and run GTK application
    win = MainWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
