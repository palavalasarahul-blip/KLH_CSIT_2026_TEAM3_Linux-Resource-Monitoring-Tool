# Zombie and Orphan Process Detection System: Academic Project Report

**Course:** Operating Systems Laboratory / Capstone  
**Degree:** Bachelor of Technology (B.Tech) in Computer Science & Engineering  
**Platform:** Ubuntu Linux (Kernel 6.x)  
**Implementation Languages:** C (Backend Process Engine) & Python 3 / GTK 3 (Frontend Diagnostic Suite)

---

## Abstract

In contemporary multitasking operating systems, process management forms the core abstraction for resource virtualization, hardware isolation, and concurrency. Two critical edge conditions in process lifecycle management are **Zombie (Defunct) processes** and **Orphan processes**. A zombie process is an inactive task whose execution has completed via `exit()`, but whose entry remains in the kernel process table because its parent has neglected to invoke `wait()` or `waitpid()`. An orphan process is an actively executing task whose parent process has terminated prematurely, requiring the kernel to reparent the orphan to the root reaper (`PID 1`, `systemd`/`init`) or a configured subreaper.

This project delivers a comprehensive, functional, and leak-free detection and demonstration system. A high-performance C backend scans `/proc` with robust string parsing (handling spaces and parentheses in process command names) and provides deterministic simulation engines for both states with POSIX timer timeouts. A native Python GTK 3 desktop suite renders live metric cards, searchable process tables, hierarchical process trees, event streams, and real-time interactive demonstration laboratories.

---

## 1. Operating Systems Theoretical Foundations

### 1.1 Process Lifecycle and Task State Machine

Under the Linux kernel, every process is represented in memory by an instance of `struct task_struct` (the Process Control Block, or PCB), defined in `<linux/sched.h>`.

```
                    +--------------------+
                    |      Created       |  (fork / clone)
                    +---------+----------+
                              |
                              v
                    +--------------------+
                    |  Ready / Running   |  (State 'R')
                    +----+----------+----+
                         |          ^
         IO wait / sleep |          | Event occurs / IO complete
                         v          |
                    +----+----------+----+
                    |  Blocked / Sleep   |  (State 'S' / 'D')
                    +---------+----------+
                              |
                              | Process terminates via exit(code)
                              v
                    +--------------------+
                    |  Zombie (Defunct)  |  (State 'Z')
                    +---------+----------+
                              |
                              | Parent invokes waitpid()
                              v
                    +--------------------+
                    |  PCB Deallocated   |  (PID released to OS)
                    +--------------------+
```

### 1.2 The Anatomy of a Zombie Process

When a process terminates in Linux:
1. The kernel invokes `do_exit()`:
   - Memory address spaces (`mm_struct`), file descriptors (`files_struct`), signal handlers, and IPC resources are deallocated.
2. The task enters state `TASK_DEAD` / `EXIT_ZOMBIE` (`'Z'`).
3. The process's exit code, termination signal, and CPU usage statistics are preserved in `task_struct`.
4. A `SIGCHLD` signal is sent to the parent process.
5. The task remains in the kernel process table until the parent acknowledges it by calling `wait()`, `waitpid()`, or `waitid()`.
6. Once `waitpid()` is executed, the kernel releases the PID slot and frees the remaining memory.

#### The Hazard of Zombie Processes:
Zombies consume 0% CPU and zero page allocations. However, they hold an entry in the system's finite PID table. On 64-bit Linux systems, `/proc/sys/kernel/pid_max` is typically configured to $32,768$ (or $4,194,304$). If a buggy server repeatedly forks workers and fails to call `wait()`, the PID table becomes exhausted, preventing any new process from being created across the entire OS (`EAGAIN: Resource temporarily unavailable`).

### 1.3 The Anatomy of an Orphan Process and Reparenting

When a parent process terminates before its children:
1. The child is still executing (State `'R'`, `'S'`, etc.).
2. Because Unix demands that every process have an active parent to harvest its exit code upon termination, the kernel's `forget_original_parent()` function searches for an ancestor to adopt the child.
3. By default, the child is reparented to `PID 1` (`systemd` or `init`).
4. Modern Linux kernels also support `prctl(PR_SET_CHILD_SUBREAPER, 1)`: any ancestor process (e.g., container runtime, user session manager `systemd --user`) can declare itself as a subreaper, capturing orphans within its subtree rather than dumping them onto PID 1.
5. When the orphaned child eventually exits, `PID 1` (which runs an event loop continuously invoking `waitpid(-1, ...)` asynchronously) reaps it immediately, preventing it from ever becoming a persistent zombie.

---

## 2. Comprehensive Comparison Matrix

| Property | Zombie Process (`State 'Z'`) | Orphan Process |
| :--- | :--- | :--- |
| **Execution State** | **Terminated / Dead** | **Actively Running / Executing** |
| **State Code in `/proc`** | `'Z'` (Zombie / Defunct) | `'S'` (Sleeping) or `'R'` (Running) |
| **Parent Relationship** | Original parent is still alive, but neglecting to call `wait()` | Original parent has terminated; reparented to `init` (PID 1) |
| **Resource Consumption** | 0% CPU, 0 MB RAM; holds 1 PID slot in kernel process table | Consumes RAM, CPU, file descriptors, network sockets |
| **Kernel Representation** | Skeleton PCB retaining exit status | Full `task_struct` with allocated memory and file descriptors |
| **Resolution Method** | Parent must call `waitpid()`; or kill parent so child is reparented to `init` | Runs to completion; `init` automatically harvests exit status |
| **System Danger** | High if leaked repeatedly: causes **PID Exhaustion** | Minimal: standard Unix background execution pattern |

---

## 3. System Architecture and Implementation

### 3.1 Module Breakdown

```
+-------------------------------------------------------------------------+
|                              Desktop GUI                                |
|          (Python 3 / GTK 3 Native Linux Application: main.py)            |
+------------------------------------+------------------------------------+
                                     |
               +---------------------+---------------------+
               |                                           |
               v                                           v
   +-----------------------+                   +-----------------------+
   |   process_monitor.py  |                   |   demo_controller.py  |
   | - Process Genealogy   |                   | - Safe Demo Manager   |
   | - Dynamic Reparenting |                   | - POSIX Signal Trap   |
   | - State Classifier    |                   | - Leak-Free Cleanup   |
   +-----------+-----------+                   +-----------+-----------+
               |                                           |
               | (Executes via pipe / JSON)                | (Executes via pipe / JSON)
               v                                           v
+-------------------------------+         +-------------------------------+
|   backend/process_detector    |         |     backend/process_demo      |
|  - High-speed /proc parser    |         |  - fork() & exit() lifecycle  |
|  - Robust stat paren parsing  |         |  - waitpid() reap execution   |
|  - JSON serialization in C    |         |  - Subreaper orphan spawn     |
+---------------+---------------+         +---------------+---------------+
                |                                         |
                +--------------------+--------------------+
                                     |
                                     v
                 +---------------------------------------+
                 |          Linux Kernel 6.x             |
                 | - /proc/[pid]/stat, status, cmdline   |
                 | - fork(), waitpid(), prctl() syscalls |
                 +---------------------------------------+
```

### 3.2 Robust `/proc/[pid]/stat` Parsing Algorithm

A notorious failure mode in Unix process monitors is naive `scanf("%d %s %c %d", &pid, comm, &state, &ppid)` parsing.
In Linux:
- `comm` can contain arbitrary whitespace (e.g. `(Web Content)`).
- `comm` can contain nested parentheses (e.g. `(sh (child))`).

**POSIX-Compliant Solution implemented in `backend/process_detector.c`:**
1. Locate the **first** occurrence of `'('` via `strchr(buffer, '(')`.
2. Locate the **last** occurrence of `')'` via `strrchr(buffer, ')')`.
3. The slice between `first + 1` and `last` is strictly guaranteed by the Linux kernel to be the complete process name.
4. Parsing of numerical fields (`state`, `ppid`, `threads`, etc.) starts strictly at `last + 1`.

### 3.3 Dynamic Process Genealogy vs. Naive PPID 1 Classification

**The Fallacy:** Many novice implementations flag every process with `PPID == 1` as an orphan.
**Why this is incorrect:** System daemons (`cron`, `systemd-resolved`, `dbus-daemon`, `sshd`) are intentionally initialized with `PPID 1` upon system boot or via service activation.
**Our Solution:**
1. **Dynamic Historical Tracking:** `process_monitor.py` tracks observed process lineages over time. A process is classified as an orphan only when its original parent was non-init (`PPID > 2`) and that parent terminated while the child was reparented to `PID 1`.
2. **Controlled Lab Registration:** Demonstration orphans are explicitly registered with their originating PID and monitored through reparenting.

---

## 4. Experimental Demonstration Protocols

### 4.1 Zombie Lifecycle Protocol
1. Coordinator executes `./backend/process_demo --zombie-spawn`.
2. The demo parent process forks child $C$.
3. Child $C$ calls `exit(42)`.
4. Parent process enters `pause()` listening for `SIGUSR1`, intentionally deferring `waitpid()`.
5. Child $C$ enters state `'Z'` in `/proc/[C]/stat`.
6. Detection engine scans `/proc`, flags $C$ with red badge, displays parent PID, and logs alert.
7. User triggers *Reap Zombie*: coordinator issues `SIGUSR1` to parent.
8. Parent executes `waitpid(C, &status, 0)`. The exit status ($42$) is harvested; the PCB is cleared from kernel memory.

### 4.2 Orphan Lifecycle Protocol
1. Coordinator executes `./backend/process_demo --orphan-spawn`.
2. Main process creates intermediate parent $P$.
3. Intermediate parent $P$ forks child $C$.
4. Child $C$ redirects standard streams to `/dev/null` and enters sleep loop with `SIGALRM` safety timeout.
5. Intermediate parent $P$ terminates immediately via `exit(0)`.
6. Kernel reparents child $C$ to `PID 1` (`systemd`).
7. Child's PPID updates from $P \to 1$.
8. System identifies and displays the reparented state with amber highlight.
9. User triggers *Stop Orphan*: child $C$ is cleanly terminated with `SIGTERM`.

---

## 5. Conclusion

This project presents a complete, mathematically and practically sound demonstration of Unix process state lifecycles. By combining a low-level, high-efficiency C engine with a modern GTK 3 desktop suite, it bridges the gap between low-level OS kernel mechanics and intuitive interactive visual diagnostics.
