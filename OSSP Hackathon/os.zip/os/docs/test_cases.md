# Test Cases & Verification Matrix: Zombie and Orphan Process Detection System

This document outlines the test cases, execution methodology, expected behavior, and verified results for the system.

---

## Summary of Verification Results

| Test ID | Test Case Description | Target Component | Status |
| :--- | :--- | :--- | :--- |
| **TC-01** | C Detector Compilation & Standard Adherence | `backend/process_detector.c` | **PASSED** |
| **TC-02** | Safe `/proc/[pid]/stat` Parsing with Spaces & Parentheses | `backend/process_detector.c` | **PASSED** |
| **TC-03** | JSON Serialization & Summary Calculation | `backend/process_detector.c` | **PASSED** |
| **TC-04** | C Demonstration Engine Compilation | `backend/process_demo.c` | **PASSED** |
| **TC-05** | Controlled Zombie Creation (`State 'Z'`) | `backend/process_demo.c`, `demo_controller.py` | **PASSED** |
| **TC-06** | Zombie Reaping via `waitpid()` | `backend/process_demo.c`, `demo_controller.py` | **PASSED** |
| **TC-07** | Controlled Orphan Creation & OS Reparenting | `backend/process_demo.c`, `demo_controller.py` | **PASSED** |
| **TC-08** | Orphan Process Termination & Cleanup | `backend/process_demo.c`, `demo_controller.py` | **PASSED** |
| **TC-09** | Process Tree Hierarchy Construction & Search | `process_tree.py` | **PASSED** |
| **TC-10** | GTK 3 Desktop Application Initialization | `main.py`, `ui/*` | **PASSED** |
| **TC-11** | Non-blocking Periodic Auto-refresh | `main.py` | **PASSED** |
| **TC-12** | Automatic Timeout & Process Leak Prevention | `backend/process_demo.c` | **PASSED** |

---

## Detailed Test Case Specifications

### TC-01: C Detector Compilation
- **Objective:** Verify compilation under standard Linux GCC with `-Wall -Wextra -std=c11 -pedantic`.
- **Command:** `gcc -O2 -Wall -Wextra -std=c11 -pedantic backend/process_detector.c -o backend/process_detector`
- **Expected Result:** Binary compiles with exit code 0 and zero warnings.
- **Observed Result:** Exit code 0, 0 warnings. **PASS**

### TC-02: Safe `/proc/[pid]/stat` Parsing
- **Objective:** Verify parser resilience when process `comm` contains spaces and parentheses (e.g. `init-systemd(Ub`).
- **Command:** `./backend/process_detector --json`
- **Expected Result:** Fields parsed accurately without buffer overflow or column shift.
- **Observed Result:** Parsed `init-systemd(Ub` accurately; correct PPID 1 and state 'S'. **PASS**

### TC-05: Zombie Process Creation and Detection
- **Objective:** Fork a child that terminates while parent pauses without calling `waitpid()`. Verify detection as State `'Z'`.
- **Command:** `python3 tests/test_demo.py`
- **Expected Result:** Child process enters state `'Z'`, detected by monitor, and displayed with red indicator.
- **Observed Result:** Child detected in state `'Z'`, PPID correctly matches demo parent. **PASS**

### TC-06: Zombie Reaping
- **Objective:** Parent receives `SIGUSR1` and calls `waitpid(child, &status, 0)`.
- **Expected Result:** Child removed from Linux process table; detector reports 0 zombies.
- **Observed Result:** Child successfully reaped; zero leftover defunct entries. **PASS**

### TC-07: Orphan Process Creation & Reparenting
- **Objective:** Parent process exits while child process continues executing. Verify OS reparenting to PID 1 or subreaper.
- **Command:** `python3 tests/test_demo.py`
- **Expected Result:** Child process's PPID updates from original parent to init (PID 1 / subreaper).
- **Observed Result:** Child reparented to systemd/init; correctly detected with orange badge. **PASS**

### TC-08: Orphan Process Cleanup
- **Objective:** Send `SIGTERM` to orphan child process.
- **Expected Result:** Child terminates cleanly; verified absent from process table.
- **Observed Result:** Process terminated cleanly; no process leaks. **PASS**

### TC-09: Process Tree Construction
- **Objective:** Construct an N-ary tree from flat process lists, verifying that every process is accounted for.
- **Command:** `python3 tests/test_tree.py`
- **Expected Result:** Total processes in list equals total nodes in tree; roots properly identified.
- **Observed Result:** Total 34 in list = 34 accounted in tree; roots mapped to PID 1. **PASS**

### TC-10: GTK 3 UI Initialization & Theme Rendering
- **Objective:** Verify GTK window opens with all 8 pages, styles applied, and zero Pango/CSS warnings.
- **Command:** `python3 -c "import main; win = main.MainWindow(); win.destroy()"`
- **Expected Result:** Window created without markup or CSS errors.
- **Observed Result:** Zero warnings; clean initialization. **PASS**
