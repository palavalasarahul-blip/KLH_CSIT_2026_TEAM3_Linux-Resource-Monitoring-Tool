# System Architecture: Zombie and Orphan Process Detection System

## 1. Architectural Overview

The Zombie and Orphan Process Detection System is structured as a two-tier hybrid architecture:
1. **Low-Level Systems Tier (C Engine):** Direct interaction with the Linux kernel via `/proc`, POSIX system calls (`fork`, `waitpid`, `exit`, `prctl`), and signal handlers (`SIGUSR1`, `SIGALRM`, `SIGTERM`).
2. **Presentation & Analytics Tier (Python GTK 3):** Event-driven desktop UI, asynchronous monitoring timers, process genealogy cache, and interactive control panels.

```mermaid
graph TD
    subgraph "Linux Kernel Space"
        K_PROC["/proc Virtual Filesystem<br/>(/proc/[pid]/stat, status, cmdline)"]
        K_PCB["Process Table / PCB Pool<br/>(struct task_struct)"]
        K_INIT["System Init / Subreaper<br/>(PID 1: systemd)"]
    end

    subgraph "Backend C Layer"
        C_DET["backend/process_detector<br/>- Robust stat parser<br/>- JSON serializer<br/>- O(N) proc traversal"]
        C_DEMO["backend/process_demo<br/>- fork() & exit()<br/>- waitpid() reap engine<br/>- Subreaper adoption"]
    end

    subgraph "Python Integration & Logic Layer"
        PY_MON["process_monitor.py<br/>- Process Genealogy Cache<br/>- Dynamic Reparenting Analyzer<br/>- State Classifier"]
        PY_CTRL["demo_controller.py<br/>- Subprocess & Pipe Coordinator<br/>- Safe Lifecycle & Cleanup"]
        PY_TREE["process_tree.py<br/>- N-ary Tree Builder<br/>- Subtree Metric Aggregator"]
    end

    subgraph "GTK 3 Desktop Presentation Layer"
        UI_MAIN["main.py (MainWindow)"]
        UI_DASH["DashboardView (Metrics & Status)"]
        UI_LIST["ProcessListView (Search & Filters)"]
        UI_ZOMB["ZombieView (Defunct Process Alerts)"]
        UI_ORPH["OrphanView (Reparenting Diagnostics)"]
        UI_TREE_V["ProcessTreeView (Hierarchical Tree)"]
        UI_DEMO_V["DemonstrationView (Interactive Lab)"]
        UI_LOG["EventLogView (Timestamped Feeds)"]
    end

    K_PROC -->|Reads /proc/[pid]| C_DET
    C_DET -->|JSON via Pipe| PY_MON
    PY_MON --> PY_TREE
    PY_MON --> UI_DASH
    PY_MON --> UI_LIST
    PY_MON --> UI_ZOMB
    PY_MON --> UI_ORPH
    PY_TREE --> UI_TREE_V

    UI_DEMO_V -->|User Action| PY_CTRL
    PY_CTRL -->|Spawns / Signals| C_DEMO
    C_DEMO -->|fork/exit| K_PCB
    K_PCB -->|Reparents| K_INIT
```

---

## 2. Data Flow & Communication Protocol

### 2.1 Backend Process Detector JSON Format
When invoked with `--json`, `process_detector` produces:
```json
[
  {
    "pid": 1298,
    "ppid": 1297,
    "name": "demo_zombie",
    "parent_name": "demo_parent",
    "state": "Z",
    "state_desc": "Zombie (Defunct)",
    "threads": 1,
    "vmsize_kb": 0,
    "vmrss_kb": 0,
    "uid": 1000,
    "user": "ubuntu",
    "cmdline": "[demo_zombie]",
    "is_zombie": true
  }
]
```

### 2.2 Controlled Demonstration Communication
```
[demo_controller.py]                 [process_demo (C)]
        |                                     |
        |--- spawn_zombie_demo() ------------>| fork() -> child exit(42)
        |<-- {"status":"zombie_created",...} -| parent pauses, leaves child 'Z'
        |                                     |
        |--- reap_zombie_demo(parent_pid) --->| sends SIGUSR1 to parent
        |<-- {"status":"zombie_reaped",...} --| parent calls waitpid(), exits
```

---

## 3. Concurrency and Non-Blocking UI Model

- The GTK 3 main loop runs on the primary thread.
- Periodic process scans are scheduled via `GLib.timeout_add_seconds(2, self._on_timer_tick)`.
- The C binary execution completes in under 15ms for typical system process tables, preventing UI micro-stutters.
- Subprocesses launched by the demonstration engine are non-blocking and monitored asynchronously.
