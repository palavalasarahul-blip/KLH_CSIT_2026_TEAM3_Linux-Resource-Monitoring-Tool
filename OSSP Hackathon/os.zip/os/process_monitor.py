"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: process_monitor.py

Description:
    Core process monitoring, classification, and lifecycle tracking engine.
    Interfaces with the compiled C backend (backend/process_detector) and
    tracks process genealogies over time to accurately distinguish between:
      1. Normal processes (Running, Sleeping, Stopped)
      2. Zombie processes (State 'Z' in /proc/[pid]/stat)
      3. True Orphan processes (Live processes whose original parent terminated
         and which were adopted by PID 1 or a configured subreaper)
      4. System Daemons / Services (Legitimate processes initialized under PID 1)

Operating Systems Concepts:
    - Process states from Linux kernel task_struct
    - Zombie process condition: terminated task waiting for parent wait()
    - Orphan process condition: parent termination triggers kernel reparenting
    - Differentiation between intentional daemons and adopted orphan processes
===============================================================================
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime
from typing import List, Dict, Any, Optional, Set


class ProcessMonitor:
    def __init__(self, backend_detector_path: Optional[str] = None):
        # Resolve backend detector executable path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        if backend_detector_path:
            self.detector_path = backend_detector_path
        else:
            self.detector_path = os.path.join(current_dir, "backend", "process_detector")

        # Process lifecycle tracking history:
        # pid -> { 'first_seen_time': float, 'original_ppid': int, 'current_ppid': int,
        #          'original_parent_name': str, 'name': str, 'is_reparented': bool }
        self._genealogy_cache: Dict[int, Dict[str, Any]] = {}

        # Explicitly registered demo orphans from demo_controller
        # child_pid -> { 'original_ppid': int, 'spawn_time': float, 'is_demo': True }
        self._registered_demo_orphans: Dict[int, Dict[str, Any]] = {}

        # Cached latest snapshot
        self.last_processes: List[Dict[str, Any]] = []
        self.last_zombies: List[Dict[str, Any]] = []
        self.last_orphans: List[Dict[str, Any]] = []
        self.last_summary: Dict[str, Any] = {
            "total": 0, "running": 0, "sleeping": 0,
            "zombie": 0, "orphan": 0, "stopped": 0,
            "disk_sleep": 0, "last_refresh": "Never"
        }

        # Subreaper / init PIDs: PID 1 is standard init/systemd
        self.reaper_pids: Set[int] = {1}
        self._detect_subreapers()

    def _detect_subreapers(self):
        """Identify PID 1 and potential subreapers in system (e.g. systemd --user)."""
        self.reaper_pids = {1}
        # In modern Linux with systemd, user session instances or container managers
        # can call prctl(PR_SET_CHILD_SUBREAPER).
        # We also check if PID 2 is kthreadd.
        try:
            if os.path.exists("/proc/1/comm"):
                with open("/proc/1/comm", "r") as f:
                    self.init_name = f.read().strip()
            else:
                self.init_name = "init"
        except Exception:
            self.init_name = "init"

    def register_demo_orphan(self, child_pid: int, original_ppid: int):
        """
        Explicitly registers an orphan process created during controlled demo.
        Guarantees 100% accurate classification for lab demonstrations.
        """
        self._registered_demo_orphans[child_pid] = {
            "original_ppid": original_ppid,
            "spawn_time": time.time(),
            "is_demo": True
        }

    def unregister_demo_orphan(self, child_pid: int):
        """Removes a finished demo orphan from registration."""
        self._registered_demo_orphans.pop(child_pid, None)

    def scan_processes(self) -> List[Dict[str, Any]]:
        """
        Executes C process_detector to collect real-time /proc process data.
        Falls back to native Python /proc parser if binary is not yet compiled.
        """
        if os.path.exists(self.detector_path) and os.access(self.detector_path, os.X_OK):
            try:
                result = subprocess.run(
                    [self.detector_path, "--json"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=5,
                    check=True
                )
                processes = json.loads(result.stdout)
            except Exception as e:
                # If C detector fails, use python fallback
                processes = self._fallback_python_scan()
        else:
            processes = self._fallback_python_scan()

        # Update genealogy and classifications
        self._classify_processes(processes)
        return processes

    def _classify_processes(self, processes: List[Dict[str, Any]]):
        """
        Applies OS process classification logic:
          - Zombie detection: state == 'Z'
          - Orphan detection:
              Case A: Explicitly registered demo process whose original parent died.
              Case B: Dynamic lifecycle observation: process was first seen with parent X != 1,
                      subsequently parent X terminated, and process now has PPID == 1/subreaper.
              Case C: Tag system daemons (PPID 1 from inception) distinctly so they aren't confused.
        """
        current_time = time.time()
        active_pids = {p["pid"] for p in processes}
        pid_to_proc = {p["pid"]: p for p in processes}

        zombies: List[Dict[str, Any]] = []
        orphans: List[Dict[str, Any]] = []

        total = len(processes)
        running = 0
        sleeping = 0
        stopped = 0
        disk_sleep = 0

        for p in processes:
            pid = p["pid"]
            ppid = p["ppid"]
            state = p["state"]
            name = p["name"]

            # Count process states
            if state == 'R':
                running += 1
            elif state == 'S':
                sleeping += 1
            elif state in ('T', 't'):
                stopped += 1
            elif state == 'D':
                disk_sleep += 1

            # --- Zombie Process Detection ---
            if state == 'Z' or p.get("is_zombie", False):
                p["is_zombie"] = True
                p["classification"] = "Zombie Process"
                p["classification_detail"] = "Process has terminated (exit called); awaiting parent wait() to release PID entry."
                zombies.append(p)
                continue

            # --- Orphan Process Detection ---
            is_orphan = False
            orphan_type = ""
            orphan_reason = ""
            orig_parent_info = ""

            # 1. Check if registered via demonstration mode
            if pid in self._registered_demo_orphans:
                demo_info = self._registered_demo_orphans[pid]
                orig_ppid = demo_info["original_ppid"]
                # If parent has exited and child reparented
                if orig_ppid not in active_pids or ppid != orig_ppid:
                    is_orphan = True
                    orphan_type = "Controlled Demo Orphan"
                    orig_parent_info = f"PID {orig_ppid} (Terminated)"
                    orphan_reason = f"Original parent (PID {orig_ppid}) exited; adopted by PID {ppid}."

            # 2. Check dynamic monitoring genealogy
            if not is_orphan:
                if pid not in self._genealogy_cache:
                    # First time seeing this process
                    self._genealogy_cache[pid] = {
                        "first_seen_time": current_time,
                        "original_ppid": ppid,
                        "original_parent_name": p.get("parent_name", "unknown"),
                        "name": name,
                        "is_reparented": False
                    }
                else:
                    cache_entry = self._genealogy_cache[pid]
                    first_ppid = cache_entry["original_ppid"]

                    # If original parent was NOT init (e.g. PPID > 2),
                    # and now current PPID IS init/reaper (PPID in self.reaper_pids),
                    # and the original parent is no longer running in active_pids:
                    if first_ppid > 2 and (ppid in self.reaper_pids) and (first_ppid not in active_pids):
                        cache_entry["is_reparented"] = True
                        is_orphan = True
                        orphan_type = "Observed Reparented Process"
                        orig_parent_info = f"PID {first_ppid} ({cache_entry.get('original_parent_name', 'terminated')})"
                        orphan_reason = f"Observed parent PID {first_ppid} terminated during monitoring; adopted by init (PID {ppid})."

            if is_orphan:
                p["is_orphan"] = True
                p["orphan_type"] = orphan_type
                p["orphan_reason"] = orphan_reason
                p["original_parent"] = orig_parent_info
                p["classification"] = "Orphan Process"
                p["classification_detail"] = orphan_reason
                orphans.append(p)
            else:
                p["is_orphan"] = False
                if ppid == 1 and pid != 1:
                    p["classification"] = "System Daemon / Init Child"
                    p["classification_detail"] = "Standard system service or daemon running under PID 1."
                elif ppid == 0:
                    p["classification"] = "Kernel / Root Process"
                    p["classification_detail"] = "Root kernel task or init process."
                else:
                    p["classification"] = "Normal Process"
                    p["classification_detail"] = f"Child of {p.get('parent_name', 'PID ' + str(ppid))} (PID {ppid})."

        # Purge dead PIDs from genealogy cache and demo tracker
        dead_pids = set(self._genealogy_cache.keys()) - active_pids
        for dpid in dead_pids:
            self._genealogy_cache.pop(dpid, None)

        dead_demo_pids = set(self._registered_demo_orphans.keys()) - active_pids
        for dpid in dead_demo_pids:
            self._registered_demo_orphans.pop(dpid, None)

        self.last_processes = processes
        self.last_zombies = zombies
        self.last_orphans = orphans
        self.last_summary = {
            "total": total,
            "running": running,
            "sleeping": sleeping,
            "zombie": len(zombies),
            "orphan": len(orphans),
            "stopped": stopped,
            "disk_sleep": disk_sleep,
            "last_refresh": datetime.now().strftime("%H:%M:%S")
        }

    def _fallback_python_scan(self) -> List[Dict[str, Any]]:
        """
        Pure Python fallback that reads /proc directly if the C executable
        is being compiled or missing.
        """
        results: List[Dict[str, Any]] = []
        proc_dir = "/proc"
        if not os.path.exists(proc_dir):
            return results

        for entry in os.listdir(proc_dir):
            if not entry.isdigit():
                continue
            pid = int(entry)
            stat_path = os.path.join(proc_dir, entry, "stat")
            try:
                with open(stat_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read().strip()
                first_p = content.find("(")
                last_p = content.rfind(")")
                if first_p == -1 or last_p == -1 or last_p < first_p:
                    continue

                name = content[first_p + 1:last_p]
                after = content[last_p + 1:].strip().split()
                if len(after) < 2:
                    continue

                state = after[0]
                ppid = int(after[1])
                threads = int(after[17]) if len(after) > 17 else 1

                # Parse status for UID and memory
                uid = 0
                vmsize = 0
                vmrss = 0
                status_path = os.path.join(proc_dir, entry, "status")
                if os.path.exists(status_path):
                    with open(status_path, "r", encoding="utf-8", errors="ignore") as sf:
                        for sline in sf:
                            if sline.startswith("Uid:"):
                                parts = sline.split()
                                if len(parts) > 1:
                                    uid = int(parts[1])
                            elif sline.startswith("VmSize:"):
                                parts = sline.split()
                                if len(parts) > 1:
                                    vmsize = int(parts[1])
                            elif sline.startswith("VmRSS:"):
                                parts = sline.split()
                                if len(parts) > 1:
                                    vmrss = int(parts[1])

                cmdline_path = os.path.join(proc_dir, entry, "cmdline")
                cmdline = f"[{name}]"
                if os.path.exists(cmdline_path):
                    try:
                        with open(cmdline_path, "rb") as cf:
                            cmd_raw = cf.read()
                            if cmd_raw:
                                cmdline = cmd_raw.replace(b"\x00", b" ").decode("utf-8", errors="ignore").strip()
                    except Exception:
                        pass

                results.append({
                    "pid": pid,
                    "ppid": ppid,
                    "name": name,
                    "parent_name": "unknown",
                    "state": state,
                    "state_desc": self._state_description(state),
                    "threads": threads,
                    "vmsize_kb": vmsize,
                    "vmrss_kb": vmrss,
                    "uid": uid,
                    "user": str(uid),
                    "cmdline": cmdline,
                    "is_zombie": (state == 'Z')
                })
            except Exception:
                continue

        # Resolve parent names
        pid_map = {p["pid"]: p["name"] for p in results}
        for p in results:
            ppid = p["ppid"]
            if ppid == 0:
                p["parent_name"] = "[kernel]"
            elif ppid in pid_map:
                p["parent_name"] = pid_map[ppid]
            else:
                p["parent_name"] = "[terminated/adopted]"

        return results

    @staticmethod
    def _state_description(state: str) -> str:
        mapping = {
            'R': "Running",
            'S': "Sleeping (Interruptible)",
            'D': "Disk Sleep (Uninterruptible)",
            'Z': "Zombie (Defunct)",
            'T': "Stopped",
            't': "Tracing Stop",
            'X': "Dead",
            'I': "Idle (Kernel Thread)"
        }
        return mapping.get(state, "Unknown")
