"""
Unit tests for the ProcessTreeBuilder and ProcessTreeNode classes.
"""

import os
import sys

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import process_monitor
import process_tree


def test_tree_construction():
    print("\n--- Testing Process Tree Construction ---")
    monitor = process_monitor.ProcessMonitor()
    procs = monitor.scan_processes()

    roots = process_tree.ProcessTreeBuilder.build_tree(procs)
    assert len(roots) > 0, "Tree must have at least one root node"

    total_in_tree = 0
    def count_nodes(node):
        cnt = 1
        for c in node.children:
            cnt += count_nodes(c)
        return cnt

    for r in roots:
        total_in_tree += count_nodes(r)

    print(f"Total processes in list: {len(procs)}, Total accounted in tree: {total_in_tree}")
    assert total_in_tree == len(procs), f"Tree process count mismatch: {total_in_tree} vs {len(procs)}"

    # Test DFS search
    target_pid = procs[0]["pid"]
    found = process_tree.ProcessTreeBuilder.find_node(roots, target_pid)
    assert found is not None
    assert found.pid == target_pid

    # Test ancestors
    ancestors = process_tree.ProcessTreeBuilder.get_ancestor_pids(found)
    print(f"Ancestors of PID {target_pid} ({found.name}): {ancestors}")

    print("SUCCESS: Process tree construction and search verified!")


if __name__ == "__main__":
    test_tree_construction()
    print("\nALL TREE TESTS PASSED SUCCESSFULLY!")
