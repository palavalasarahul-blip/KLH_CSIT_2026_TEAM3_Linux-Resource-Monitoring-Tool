"""
Test script for verifying Zombie and Orphan demonstrations and cleanup.
"""

import os
import sys
import time

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import process_monitor
import demo_controller


def test_zombie_lifecycle():
    print("\n--- Testing Zombie Process Lifecycle ---")
    monitor = process_monitor.ProcessMonitor()
    controller = demo_controller.DemoController(monitor)

    # 1. Clean any initial state
    controller.stop_all_demos()

    # 2. Spawn zombie demo
    res = controller.spawn_zombie_demo()
    assert res.get("status") == "success", f"Zombie spawn failed: {res}"
    parent_pid = res["parent_pid"]
    child_pid = res["child_pid"]
    print(f"Spawned Zombie: Parent PID={parent_pid}, Child PID={child_pid}")

    # Brief delay for /proc to settle
    time.sleep(0.5)

    # 3. Detect via monitor
    monitor.scan_processes()
    zombies = monitor.last_zombies
    print(f"Detected {len(zombies)} zombie(s) in system:")
    for z in zombies:
        print(f"  -> PID: {z['pid']}, PPID: {z['ppid']}, Name: {z['name']}, State: {z['state']}")

    matching = [z for z in zombies if z["pid"] == child_pid]
    assert len(matching) == 1, f"Expected child {child_pid} to be in zombie list"
    assert matching[0]["state"] == "Z", f"Expected state 'Z', got {matching[0]['state']}"
    assert matching[0]["ppid"] == parent_pid, f"Expected PPID {parent_pid}, got {matching[0]['ppid']}"
    print("SUCCESS: Zombie process correctly identified in State 'Z'!")

    # 4. Reap zombie
    reap_res = controller.reap_zombie_demo()
    assert reap_res.get("status") == "reaped", f"Reap failed: {reap_res}"
    print(f"Reaped Zombie: {reap_res}")

    time.sleep(0.5)
    monitor.scan_processes()
    matching_after = [z for z in monitor.last_zombies if z["pid"] == child_pid]
    assert len(matching_after) == 0, f"Child {child_pid} should no longer be present"
    print("SUCCESS: Zombie cleanly reaped and removed from process table!")


def test_orphan_lifecycle():
    print("\n--- Testing Orphan Process Lifecycle ---")
    monitor = process_monitor.ProcessMonitor()
    controller = demo_controller.DemoController(monitor)

    # 1. Clean state
    controller.stop_all_demos()

    # 2. Spawn orphan demo
    res = controller.spawn_orphan_demo()
    assert res.get("status") == "success", f"Orphan spawn failed: {res}"
    child_pid = res["child_pid"]
    orig_ppid = res["original_ppid"]
    new_ppid = res["new_ppid"]
    print(f"Spawned Orphan: Child PID={child_pid}, Original Parent PID={orig_ppid}, Reparented PPID={new_ppid}")

    time.sleep(0.5)

    # 3. Detect via monitor
    monitor.scan_processes()
    orphans = monitor.last_orphans
    print(f"Detected {len(orphans)} orphan(s) in system:")
    for o in orphans:
        print(f"  -> PID: {o['pid']}, Current PPID: {o['ppid']}, Name: {o['name']}, Type: {o['orphan_type']}, Reason: {o['orphan_reason']}")

    matching = [o for o in orphans if o["pid"] == child_pid]
    assert len(matching) == 1, f"Expected child {child_pid} in orphan list"
    assert matching[0]["is_orphan"] is True
    print("SUCCESS: Orphan process correctly detected and reparenting confirmed!")

    # 4. Stop orphan demo
    stop_res = controller.stop_orphan_demo()
    assert stop_res.get("status") == "stopped", f"Stop orphan failed: {stop_res}"
    print(f"Stopped Orphan: {stop_res}")

    time.sleep(0.5)
    monitor.scan_processes()
    matching_after = [o for o in monitor.last_orphans if o["pid"] == child_pid]
    assert len(matching_after) == 0, f"Child {child_pid} should no longer be present"
    print("SUCCESS: Orphan cleanly stopped with no leftover process!")


if __name__ == "__main__":
    test_zombie_lifecycle()
    test_orphan_lifecycle()
    print("\nALL DEMONSTRATION TESTS PASSED SUCCESSFULLY!")
