"""
Unit tests for the C process_detector and Python ProcessMonitor integration.
"""

import os
import sys
import json
import subprocess

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import process_monitor


def test_detector_executable():
    print("\n--- Testing C Process Detector Binary ---")
    current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    detector_bin = os.path.join(current_dir, "backend", "process_detector")

    assert os.path.exists(detector_bin), f"Binary not found: {detector_bin}"

    # Test --summary flag
    res = subprocess.run([detector_bin, "--summary"], stdout=subprocess.PIPE, text=True, check=True)
    summary_data = json.loads(res.stdout)
    print("Summary output:", summary_data)
    assert "total" in summary_data
    assert "running" in summary_data
    assert "sleeping" in summary_data
    assert summary_data["total"] > 0
    print("SUCCESS: process_detector --summary verified!")

    # Test --json flag
    res = subprocess.run([detector_bin, "--json"], stdout=subprocess.PIPE, text=True, check=True)
    proc_list = json.loads(res.stdout)
    assert isinstance(proc_list, list)
    assert len(proc_list) > 0

    first = proc_list[0]
    required_fields = ["pid", "ppid", "name", "parent_name", "state", "threads", "uid", "cmdline"]
    for f in required_fields:
        assert f in first, f"Missing field {f} in process json"

    print(f"SUCCESS: process_detector --json verified with {len(proc_list)} processes!")


def test_monitor_scanning():
    print("\n--- Testing Python ProcessMonitor Class ---")
    monitor = process_monitor.ProcessMonitor()
    procs = monitor.scan_processes()

    assert len(procs) > 0
    assert monitor.last_summary["total"] == len(procs)
    assert "last_refresh" in monitor.last_summary

    # Verify classifications exist
    for p in procs:
        assert "classification" in p
        assert p["state"] in ('R', 'S', 'D', 'Z', 'T', 't', 'I', 'X', '?')

    print(f"SUCCESS: ProcessMonitor scanned {len(procs)} processes with valid classifications!")


if __name__ == "__main__":
    test_detector_executable()
    test_monitor_scanning()
    print("\nALL DETECTOR TESTS PASSED SUCCESSFULLY!")
