# Zombie and Orphan Process Detection System

A complete, production-grade Linux Operating Systems project for detecting, classifying, and demonstrating **Zombie** and **Orphan** processes in real-time. Built from scratch with a high-performance **C backend** and a native **Python / GTK 3 desktop GUI**, tailored for academic evaluation and demonstration.

---

## 1. Project Overview

In Unix-like operating systems such as Ubuntu Linux, the kernel maintains a Process Table storing metadata (the Process Control Block, or PCB) for every active task. During process execution, two classic lifecycle phenomena emerge:
1. **Zombie Processes (State `Z`):** A process that has terminated via `exit()`, but its PCB remains in the process table because its parent has not yet collected its exit code using `wait()` or `waitpid()`.
2. **Orphan Processes:** An executing process whose original parent has terminated prematurely, prompting the Linux kernel to adopt and reparent the orphan to the root reaper (`PID 1`, `systemd` / `init`) or a configured subreaper.

This system provides a live, interactive desktop dashboard, an automated `/proc` scanner, an N-ary process hierarchy tree, and a controlled demonstration laboratory where students and evaluators can safely create, inspect, reap, and clean up both process types with zero risk of system instability.

---

## 2. Problem Statement

Modern software systems and daemon architectures often encounter concurrency bugs:
- **PID Table Exhaustion:** Unchecked zombie processes hold finite PID slots (`/proc/sys/kernel/pid_max`), eventually preventing new processes from starting.
- **Misclassification of System Daemons:** Many naive tools mistakenly flag every process with `PPID 1` as an orphan, confusing essential background daemons (e.g. `cron`, `sshd`, `dbus-daemon`) with true reparented orphans.
- **Lack of Interactive Educational Tooling:** Operating systems coursework often teaches `fork()` and `wait()` theoretically, without providing intuitive visualization of PCB lifecycles and kernel adoption.

---

## 3. Key Concepts Explained in Simple Language

### What is a Zombie Process?
> **Analogy:** Imagine a worker completing a task, submitting their final report card to the company inbox, and clocking out. The worker is gone, but their report card stays in the inbox until their manager picks it up. If the manager never collects the report card, it clutters the desk indefinitely.

In Linux:
1. Child executes `exit(42)`.
2. Kernel frees its virtual memory, closed files, and buffers.
3. The child's exit code is held in the Process Table in **State `Z` (Zombie / Defunct)**.
4. When the parent calls `waitpid()`, the kernel releases the PID slot.

### What is an Orphan Process?
> **Analogy:** Imagine a parent bird flying away before its chick has learned to fly. The chick is alive and healthy, but has no parent. A sanctuary shelter (`PID 1` / `init`) steps in and legally adopts the chick, looking after it until it leaves the nest.

In Linux:
1. Parent process terminates before the child.
2. The child continues running normally (State `S` or `R`).
3. The Linux kernel notices the child has no living parent and **reparents** it to `PID 1` (`systemd`).
4. When the orphan eventually terminates, `PID 1` automatically reaps it.

### Core Differences Table

| Feature | Zombie Process | Orphan Process |
| :--- | :--- | :--- |
| **Current State** | **Dead / Terminated** (State `Z`) | **Alive / Executing** (State `S` or `R`) |
| **Parent Status** | Original parent is alive, but neglecting `wait()` | Original parent is dead and gone |
| **Parent ID (PPID)** | Points to living parent | Points to `PID 1` (or subreaper) |
| **CPU / RAM Usage** | **0% CPU, 0 MB RAM** | Consumes normal CPU and RAM |
| **OS Danger** | Leaks PID table entries (**PID exhaustion**) | Safe; harvested automatically by `init` |
| **How to Fix** | Parent must call `waitpid()`, or kill parent | Automatically handled when process finishes |

---

## 4. Key Features

- **Executive Dashboard:** Live cards displaying Total, Running, Sleeping, Zombie, and Orphan processes, paired with dynamic health status banners.
- **Robust Zombie Detection:** Identifies processes in state `Z` in `/proc/[pid]/stat`, mapping parent names and diagnosing uncalled `wait()` conditions.
- **Dynamic Orphan Tracking:** Avoids false positives by maintaining process genealogies over time; distinguishes legitimate system daemons (`PPID 1`) from true reparented children.
- **Interactive Process Tree:** Hierarchical N-ary tree powered by `Gtk.TreeStore` with expandable nodes, descendant counters, and instant anomaly location.
- **Full Process Explorer:** Instant search bar, state filters (Running, Sleeping, Zombie, Orphan, Stopped), sortable columns, and memory/cmdline inspection panels.
- **Controlled Demonstration Lab:**
  - One-click **Zombie Creation** (`fork()` $\to$ child `exit()` $\to$ parent sleep) and **Reaping** (`waitpid()`).
  - One-click **Orphan Creation** (parent `exit()` $\to$ kernel reparenting to `PID 1`).
  - Automated 60-second safety timeouts (`SIGALRM`) ensuring **zero leftover processes**.
- **Real-Time Event Log:** Timestamped event stream recording monitoring events, anomalies, and reap actions, with file export capability.
- **Academic OS Guide:** Comprehensive built-in reference explaining process state diagrams, system calls, and `/proc` mechanics.

---

## 5. Technology Stack

- **Backend Logic:** C (C11 standard, compiled with GCC).
- **Desktop Frontend:** Python 3 (PyGObject, GTK 3).
- **Styling:** Custom Vanilla GTK CSS (`ui/style.css`).
- **IPC & System Inspection:** Linux `/proc` filesystem, POSIX pipes, and structured JSON.
- **Build System:** GNU Makefile.
- **Operating System:** Ubuntu Linux (tested on Ubuntu 24.04 LTS / Kernel 6.x).

---

## 6. Architecture & Folder Structure

```
zombie-orphan-detector/
├── main.py                     # Desktop application entry point & GTK controller
├── process_monitor.py          # Process scanner, genealogy tracking & classification
├── process_tree.py             # N-ary process hierarchy tree builder
├── demo_controller.py          # Safe demonstration coordinator & signal manager
├── Makefile                    # Build automation (all, run, test, clean)
├── requirements.txt            # Python & system dependencies
├── README.md                   # Comprehensive user and developer manual
├── backend/
│   ├── process_detector.c      # High-performance Linux /proc parser in C
│   └── process_demo.c          # Deterministic zombie & orphan demonstration engine
├── ui/
│   ├── style.css               # Sleek modern dark GTK 3 theme
│   ├── dashboard_view.py       # Metrics, cards & health status banner
│   ├── process_list_view.py    # Searchable, filterable process table
│   ├── zombie_view.py          # Dedicated zombie process diagnostics
│   ├── orphan_view.py          # Dedicated orphan process reparenting diagnostics
│   ├── tree_view.py            # Hierarchical expandable process tree
│   ├── demo_view.py            # Interactive demonstration laboratory
│   ├── log_view.py             # Timestamped event log & export
│   └── about_view.py           # Academic OS concepts & viva study guide
├── tests/
│   ├── test_detector.py        # Unit tests for C detector & Python monitor
│   ├── test_tree.py            # Unit tests for process tree construction
│   └── test_demo.py            # Integration tests for zombie & orphan lifecycles
└── docs/
    ├── project_documentation.md# Academic report for B.Tech submission
    ├── architecture.md         # Mermaid diagrams & communication specs
    └── test_cases.md           # Verification matrix and test specifications
```

---

## 7. Ubuntu Installation Instructions

### Prerequisites
Open a terminal on your Ubuntu system and install the required build tools and libraries:

```bash
sudo apt update
sudo apt install -y build-essential gcc make python3 python3-pip python3-gi python3-gi-cairo gir1.2-gtk-3.0
```

*Note: No internet connection is needed once these standard Ubuntu packages are installed.*

---

## 8. Compilation and Execution

### Build the Project
Compile the C backend binaries:
```bash
make
```

### Run the Desktop Application
Launch the GTK 3 GUI:
```bash
make run
```
*(Alternatively, execute `python3 main.py` directly).*

### Run Automated Tests
Execute the full verification test suite:
```bash
make test
```

### Clean Up Build Artifacts
Remove binaries and temporary caches:
```bash
make clean
```

---

## 9. Step-by-Step Demonstration Guide

### Demonstration 1: Zombie Process Detection & Reaping
1. Launch the application: `make run`.
2. Click **🧪 Demonstrations** on the left sidebar.
3. Click the red **Create Zombie Demo** button.
   - The engine calls `fork()`. The child terminates immediately with `exit(42)`.
   - The parent process intentionally sleeps without calling `waitpid()`.
4. Observe the live status:
   - Dashboard banner turns **RED**: `WARNING: 1 Zombie Process Detected!`.
   - The Zombie card increments to `1`.
5. Switch to **🧟 Zombie Processes**:
   - Notice the row with `PID`, `demo_zombie`, State `Z`, and Parent Name `demo_parent`.
6. Switch to **🌲 Process Tree**:
   - Click **🔍 Locate Zombie / Orphan**. The tree expands and highlights the defunct child node in **RED**.
7. Return to **🧪 Demonstrations** and click **Reap Zombie (waitpid)**:
   - Parent receives `SIGUSR1` and calls `waitpid()`.
   - The zombie is cleanly removed from the Linux process table.
   - Dashboard status returns to **Healthy (Green)**.

### Demonstration 2: Orphan Process Reparenting
1. Under **🧪 Demonstrations**, click the amber **Create Orphan Demo** button.
   - Intermediate parent process forks child and terminates immediately (`exit(0)`).
   - Child process continues running in a sleep loop.
   - Linux kernel reparents the child to `PID 1` (`systemd` / `init`).
2. Observe the live status:
   - Dashboard shows `1` in Detected Orphans.
3. Switch to **🐣 Orphan Processes**:
   - The table displays the child PID, adopted PPID (`1`), original parent PID, and reason.
4. Click **Stop Orphan Demo** (or click **🧹 Stop All Demos**):
   - Child is safely terminated with `SIGTERM`.

---

## 10. Sample Terminal Outputs

### Automated Test Suite Execution (`make test`):
```text
>>> Running Detector Test Suite...
python3 tests/test_detector.py
Summary output: {'total': 34, 'running': 1, 'sleeping': 33, 'zombie': 0, ...}
SUCCESS: process_detector --summary verified!
SUCCESS: process_detector --json verified with 34 processes!
ALL DETECTOR TESTS PASSED SUCCESSFULLY!

>>> Running Process Tree Test Suite...
python3 tests/test_tree.py
Total processes in list: 34, Total accounted in tree: 34
SUCCESS: Process tree construction and search verified!
ALL TREE TESTS PASSED SUCCESSFULLY!

>>> Running Zombie & Orphan Demonstration Test Suite...
python3 tests/test_demo.py
--- Testing Zombie Process Lifecycle ---
[ALERT] Zombie created! Child PID 1298 terminated; Parent PID 1297 has not called waitpid(). Child is in state 'Z'.
Detected 1 zombie(s) in system:
  -> PID: 1298, PPID: 1297, Name: demo_zombie, State: Z
SUCCESS: Zombie process correctly identified in State 'Z'!
[INFO] Zombie PID 1298 successfully reaped by Parent PID 1297 via waitpid().
SUCCESS: Zombie cleanly reaped and removed from process table!

--- Testing Orphan Process Lifecycle ---
[ALERT] Orphan created! Original Parent PID 1304 terminated. Child PID 1305 has been reparented by kernel to PID 1244 (init/subreaper).
Detected 1 orphan(s) in system:
  -> PID: 1305, Current PPID: 1244, Name: demo_orphan, Type: Controlled Demo Orphan
SUCCESS: Orphan process correctly detected and reparenting confirmed!
[INFO] Orphan demo process PID 1305 terminated and cleaned up safely.
SUCCESS: Orphan cleanly stopped with no leftover process!

ALL DEMONSTRATION TESTS PASSED SUCCESSFULLY!
```

---

## 11. Edge Cases Handled

1. **Process Names with Spaces & Parentheses:** Handled safely in C by finding the *first* `(` and *last* `)` in `/proc/[pid]/stat`.
2. **Disappearing Processes:** Processes terminating during `/proc` iteration are caught gracefully without application crash.
3. **No Process Leaks:** Demonstrations feature automated 60-second `SIGALRM` safety timers. Window closure triggers automatic reap of all demo tasks.
4. **Daemon Disambiguation:** Tracks process genealogies over time so legitimate system daemons running under `PID 1` are not incorrectly branded as orphans.
5. **Non-Root Execution:** Runs entirely in unprivileged user space without requiring `sudo`.

---

## 12. Limitations & Future Enhancements

### Limitations
- **Subreaper Tracking in Containers:** Inside non-init Docker containers, `PID 1` may be a shell or custom runner rather than systemd.
- **Kernel Threads:** Processes with `PPID 0` (e.g. `kthreadd`) do not have conventional parent processes.

### Future Enhancements
- **eBPF System Call Tracing:** Integrate eBPF kprobes on `sys_enter_wait4` and `sys_enter_exit_group` for sub-millisecond event capture.
- **Automated Remediation Daemon:** Auto-signal parent processes that accumulate more than $N$ zombie children.

---

## 13. Conclusion

The **Zombie and Orphan Process Detection System** provides a complete, robust, and academically rigorous implementation of Unix process management principles. By unifying real-time Linux `/proc` analysis, POSIX system calls, and an intuitive GTK 3 graphical user interface, it bridges low-level kernel mechanics with practical software diagnostics.
