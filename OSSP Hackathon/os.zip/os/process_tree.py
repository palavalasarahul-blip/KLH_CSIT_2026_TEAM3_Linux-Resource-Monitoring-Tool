"""
===============================================================================
Project: Zombie and Orphan Process Detection System
File: process_tree.py

Description:
    Hierarchical process tree builder and parent-child relationship engine.
    Constructs an N-ary tree of active system processes, flags zombie and orphan
    nodes, computes subtree metrics, and populates GTK TreeStore models.

Operating Systems Concepts:
    - Process hierarchy (tree structure anchored at init/PID 1 and kthreadd/PID 2)
    - Parent Process ID (PPID) to Process ID (PID) mapping
    - Subtree inheritance and reparenting paths
    - Visual differentiation of defunct (zombie) and adopted (orphan) nodes
===============================================================================
"""

from typing import List, Dict, Any, Optional


class ProcessTreeNode:
    def __init__(self, data: Dict[str, Any]):
        self.data: Dict[str, Any] = data
        self.pid: int = data.get("pid", 0)
        self.ppid: int = data.get("ppid", 0)
        self.name: str = data.get("name", "unknown")
        self.state: str = data.get("state", "?")
        self.state_desc: str = data.get("state_desc", "Unknown")
        self.is_zombie: bool = data.get("is_zombie", False)
        self.is_orphan: bool = data.get("is_orphan", False)
        self.classification: str = data.get("classification", "Normal Process")

        self.children: List["ProcessTreeNode"] = []
        self.parent: Optional["ProcessTreeNode"] = None
        self.total_descendants: int = 0
        self.has_zombie_child: bool = False
        self.has_orphan_child: bool = False

    def add_child(self, child: "ProcessTreeNode"):
        child.parent = self
        self.children.append(child)

    def calculate_metrics(self):
        """Recursively computes descendant counts and anomaly flags."""
        count = len(self.children)
        zombie_found = False
        orphan_found = False

        for child in self.children:
            child.calculate_metrics()
            count += child.total_descendants
            if child.is_zombie or child.has_zombie_child:
                zombie_found = True
            if child.is_orphan or child.has_orphan_child:
                orphan_found = True

        self.total_descendants = count
        self.has_zombie_child = zombie_found
        self.has_orphan_child = orphan_found


class ProcessTreeBuilder:
    @staticmethod
    def build_tree(processes: List[Dict[str, Any]]) -> List[ProcessTreeNode]:
        """
        Constructs a list of root ProcessTreeNodes from flat process dictionaries.
        Roots are processes with PPID == 0 or whose PPID is not in the process list.
        """
        nodes: Dict[int, ProcessTreeNode] = {}
        for p in processes:
            pid = p["pid"]
            nodes[pid] = ProcessTreeNode(p)

        roots: List[ProcessTreeNode] = []

        for pid, node in nodes.items():
            ppid = node.ppid
            if ppid in nodes and ppid != pid:
                # Normal parent-child relationship
                nodes[ppid].add_child(node)
            else:
                # Root process (e.g., PID 1 systemd/init, PID 2 kthreadd, or unmapped parent)
                roots.append(node)

        # Sort roots and children by PID for stable, consistent view
        roots.sort(key=lambda n: n.pid)
        for node in nodes.values():
            node.children.sort(key=lambda c: c.pid)
            node.calculate_metrics()

        return roots

    @staticmethod
    def find_node(roots: List[ProcessTreeNode], target_pid: int) -> Optional[ProcessTreeNode]:
        """Depth-first search for a specific PID in the tree."""
        for root in roots:
            res = ProcessTreeBuilder._dfs_find(root, target_pid)
            if res:
                return res
        return None

    @staticmethod
    def _dfs_find(current: ProcessTreeNode, target_pid: int) -> Optional[ProcessTreeNode]:
        if current.pid == target_pid:
            return current
        for child in current.children:
            res = ProcessTreeBuilder._dfs_find(child, target_pid)
            if res:
                return res
        return None

    @staticmethod
    def get_ancestor_pids(node: ProcessTreeNode) -> List[int]:
        """Returns the list of ancestor PIDs up to the root."""
        ancestors: List[int] = []
        curr = node.parent
        while curr:
            ancestors.append(curr.pid)
            curr = curr.parent
        return ancestors
